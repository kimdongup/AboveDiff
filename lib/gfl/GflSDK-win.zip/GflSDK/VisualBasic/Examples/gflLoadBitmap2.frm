VERSION 5.00
Begin VB.Form Form14 
   Caption         =   "Form14"
   ClientHeight    =   5970
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   7965
   LinkTopic       =   "Form14"
   ScaleHeight     =   5970
   ScaleWidth      =   7965
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form14"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflLoadBitmap
' gflLibraryInit
' gflGetDefaultLoadParams
' gflEnableLZW
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extShowTransparencyBitmapOnDCEx
' gflFreeBitmap
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
'
' ------------------------------


Private Sub Form_Load()
Dim GflBitmap As GFL_BITMAP
Dim PtrBitmap As Long
Dim LoadParams As GFL_LOAD_PARAMS
Dim FileInfo As GFL_FILE_INFORMATION
Dim Error As Integer

gflLibraryInit 'Initialize the library
gflGetDefaultLoadParams LoadParams 'Gets default parameters for loading

With LoadParams
    .ChannelOrder = GFL_BGR 'Component order like DIB
    .LinePadding = 4 'Line padding on 4 bytes (32bits)
    .Flags = GFL_LOAD_SKIP_ALPHA 'No alpha layer
End With

gflEnableLZW True   'Activate LZW compression (be carefull! you must have a license, see on unisys site)
Me.AutoRedraw = True

Error = gflLoadBitmap(App.Path & "\image.gif", PtrBitmap, LoadParams, FileInfo) 'Load picture
If Error = GFL_NO_ERROR Then 'If no error
    extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the picture data
    extShowTransparencyBitmapOnDCEx GflBitmap, Me.hdc, vbRed 'Display picture on the DC with the red color for mask
    gflFreeBitmapData GflBitmap 'Free bitmap
End If

gflLibraryExit 'Quit the library
End Sub
