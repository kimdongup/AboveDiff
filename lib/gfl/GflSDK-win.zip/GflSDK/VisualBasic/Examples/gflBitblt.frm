VERSION 5.00
Begin VB.Form Form13 
   Caption         =   "Form13"
   ClientHeight    =   4755
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   10635
   LinkTopic       =   "Form13"
   ScaleHeight     =   4755
   ScaleWidth      =   10635
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Picture3 
      Height          =   3615
      Left            =   6720
      ScaleHeight     =   3555
      ScaleWidth      =   3195
      TabIndex        =   2
      Top             =   0
      Width           =   3255
   End
   Begin VB.PictureBox Picture2 
      Height          =   3615
      Left            =   3360
      ScaleHeight     =   3555
      ScaleWidth      =   3195
      TabIndex        =   1
      Top             =   0
      Width           =   3255
   End
   Begin VB.PictureBox Picture1 
      Height          =   3615
      Left            =   0
      ScaleHeight     =   3555
      ScaleWidth      =   3195
      TabIndex        =   0
      Top             =   0
      Width           =   3255
   End
End
Attribute VB_Name = "Form13"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflLoadBitmap
' gflLibraryInit
' gflGetDefaultLoadParams
' gflBitblt
' gflEnableLZW
' gflFreeBitmap
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extShowBitmapOnDc
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
' GFL_RECT
'
' ------------------------------

Private Sub Form_Load()
Dim GflBitmap1 As GFL_BITMAP, GflBitmap2 As GFL_BITMAP
Dim PtrBitmap1 As Long, PtrBitmap2 As Long
Dim Error1 As Integer, Error2 As Integer, Error3 As Integer
Dim LoadParams As GFL_LOAD_PARAMS
Dim FileInfo As GFL_FILE_INFORMATION
Dim GflRect As GFL_RECT

gflLibraryInit 'Initialize the library
gflGetDefaultLoadParams LoadParams 'Gets default parameters for loading
gflEnableLZW True 'Activate LZW compression (be carefull! need license from unisys)

With LoadParams
    .Flags = GFL_LOAD_SKIP_ALPHA 'No alpha layer
    .ColorModel = GFL_BGR 'Component order like DIB
    .Origin = GFL_BOTTOM_LEFT 'Origin is bottom-left
    .LinePadding = 4 'Line padding on 4 bytes (32bits)
End With
Picture1.AutoRedraw = True
Picture2.AutoRedraw = True
Picture3.AutoRedraw = True

Error1 = gflLoadBitmap(App.Path & "\image2.jpg", PtrBitmap1, LoadParams, FileInfo) 'Load the first picture
If Error1 = GFL_NO_ERROR Then 'If no error
    extGetGflBitmapFromPtr PtrBitmap1, GflBitmap1 'Get the data in GflBitmap1
    extShowBitmapOnDc GflBitmap1, Picture1.hdc 'Display on the DC of picture1
End If

Error2 = gflLoadBitmap(App.Path & "\image.gif", PtrBitmap2, LoadParams, FileInfo) 'Load the second picture
If Error2 = GFL_NO_ERROR Then 'If no error
    extGetGflBitmapFromPtr PtrBitmap2, GflBitmap2 'Get the data in Gflbitmap2
    extShowBitmapOnDc GflBitmap2, Picture2.hdc 'Display on the DC of picture2
    
    'gflBitBlt accept only bitmap of the same type, change the second (colors) in BGR
    Error2 = gflChangeColorDepth(GflBitmap2, PtrBitmap2, GFL_MODE_TO_BGR, GFL_MODE_NO_DITHER)
    If Error2 = GFL_NO_ERROR Then extGetGflBitmapFromPtr PtrBitmap2, GflBitmap2 'If no error, get the data
End If

If Error1 = GFL_NO_ERROR And Error2 = GFL_NO_ERROR Then 'If all pictures are loaded
    
    GflRect.x = 0                   'Size of the new bitmap
    GflRect.y = 0
    GflRect.h = GflBitmap2.Height
    GflRect.w = GflBitmap2.Width
    
    Error3 = gflBitblt(GflBitmap2, GflRect, GflBitmap1, 10, 10) 'BitBlt picture
    If Error3 = GFL_NO_ERROR Then extShowBitmapOnDc GflBitmap1, Picture3.hdc 'Display result on the DC of picture3

    gflFreeBitmapData GflBitmap1 'Free bitmap
    gflFreeBitmapData GflBitmap2
End If
gflLibraryExit 'Quit the library
End Sub


