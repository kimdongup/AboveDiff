VERSION 5.00
Begin VB.Form Form4 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form4"
   ClientHeight    =   3255
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   4695
   LinkTopic       =   "Form4"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3255
   ScaleWidth      =   4695
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   3255
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   4695
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
' gflLibraryInit
' gflJpegLosslessTransform
' gflLibraryExit
' ------------------------------

Option Explicit

Private Sub Form_Load()
Dim File As String
Dim Ret As Integer

gflLibraryInit

File = App.Path & "\image.jpg"
Ret = gflJpegLosslessTransform(File, GFL_LOSSLESS_TRANSFORM_ROTATE90)
If Ret = GFL_NO_ERROR Then Text1.text = "Lossless rotation of 90�!"

gflLibraryExit
End Sub

