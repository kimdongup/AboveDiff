VERSION 5.00
Begin VB.Form Form6 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form6"
   ClientHeight    =   3855
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   4695
   LinkTopic       =   "Form6"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3855
   ScaleWidth      =   4695
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   3855
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   4695
   End
End
Attribute VB_Name = "Form6"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflGetDefaultLoadParams
' gflGetDefaultSaveParams
' gflLoadBitmap
' gflGetFormatIndexByName
' gflSaveBitmapIntoHandle
' gflFreeBitmap
'
' gflLibraryInit
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extGetStr
' extFarProc
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_SAVE_PARAMS
' GFL_FILE_INFORMATION
'
' Module GflSaveData
' ------------------------------

Option Explicit

Private Sub Form_Load()
Dim GflBitmap As GFL_BITMAP
Dim PtrBitmap As Long
Dim GflLoadParams As GFL_LOAD_PARAMS
Dim GflSaveParams As GFL_SAVE_PARAMS
Dim GflInfo As GFL_FILE_INFORMATION
Dim Error As Integer

gflLibraryInit 'Initialize the library
gflGetDefaultLoadParams GflLoadParams 'Gets default parameters for loading
gflGetDefaultSaveParams GflSaveParams 'Gets default parameters for saving

Error = gflLoadBitmap(App.Path & "\image.jpg", PtrBitmap, GflLoadParams, GflInfo) 'Load bitmap in memory
If Error = GFL_NO_ERROR Then 'Si aucune erreur
    extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the picture data
    
    With GflSaveParams.Callbacks
        .Write = extFarProc(AddressOf WRITE_WriteFunction) 'Set the CallBacks
        .Tell = extFarProc(AddressOf WRITE_TellFunction)
        .Seek = extFarProc(AddressOf WRITE_SeekFunction)
    End With
    
    GflSaveParams.FormatIndex = gflGetFormatIndexByName("png") 'Set the writing format
    
    Error = gflSaveBitmapIntoHandle(VarPtr(SData), GflBitmap, GflSaveParams) 'Write the file in memory using the SData strucutre (copy of SAVE_DATA)
    If Error = GFL_NO_ERROR Then
        extSaveFile App.Path & "\image.png", SData 'If no error, save the picture
        Text1.text = "File saved !"
        gflMemoryFree SData.Data 'Free SData
    End If
    
    gflFreeBitmapData GflBitmap 'Free bitmap
End If
    
If Error <> GFL_NO_ERROR Then MsgBox "Error : " & extGetStr(gflGetErrorString(Error)) & " (" & Error & ")" 'If no error, display it

gflLibraryExit 'Quit library
End Sub

