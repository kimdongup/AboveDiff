VERSION 5.00
Begin VB.Form Form9 
   AutoRedraw      =   -1  'True
   Caption         =   "Form9"
   ClientHeight    =   6360
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   9420
   LinkTopic       =   "Form9"
   ScaleHeight     =   6360
   ScaleWidth      =   9420
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form9"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' This function explains how to load a picture in a DDB
' To convert it in bitmap, and in DIB for displaying
'
' gflLoadBitmapIntoDDB
' gflConvertDDBIntoBitmap
' gflConvertBitmapIntoDIB
'
' gflLibraryInit
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extGetDIBfromPtr
' extGetStr
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
'
' ------------------------------

Option Explicit

Private Type Rect
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type

Private Declare Function FillRect Lib "user32" (ByVal hdc As Long, lpRect As Rect, ByVal hBrush As Long) As Long
Private Declare Function CreateSolidBrush Lib "gdi32" (ByVal crColor As Long) As Long
Private Declare Function GetDC Lib "user32" (ByVal hwnd As Long) As Long
Private Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function ReleaseDC Lib "user32" (ByVal hwnd As Long, ByVal hdc As Long) As Long
Private Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Private Declare Function DeleteDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long

Private Sub Form_Load()
Dim GflBitmap As GFL_BITMAP
Dim GflParams As GFL_LOAD_PARAMS
Dim GflInfo As GFL_FILE_INFORMATION
Dim PtrBitmap As Long
Dim File As String
Dim Error As Integer

Dim hBitmap As Long
Dim hdc As Long
Dim hMemoryDC As Long
Dim holdDC As Long
Dim hBrush As Long
Dim Rect As Rect

gflLibraryInit

File = App.Path & "\image.jpg"
Error = gflLoadBitmapIntoDDB(File, hBitmap, GflParams, GflInfo) 'Load the file in a DIB format

If Error = GFL_NO_ERROR Then 'If no error
    Rect.Left = 10 'Set the size of filled rectangle
    Rect.Top = 10
    Rect.Bottom = 50
    Rect.Right = 50
    hBrush = CreateSolidBrush(RGB(255, 0, 0))           'Fill color
    
    hdc = GetDC(&H0)                                    'Obtain context of the desktop
    hMemoryDC = CreateCompatibleDC(hdc)                 'Create a temporary context from hDC
    ReleaseDC &H0, hdc                                  'Free context of desktop
    holdDC = SelectObject(hMemoryDC, hBitmap)           'Select bitmap in the context
    FillRect hMemoryDC, Rect, hBrush                    'Fill the rectangle
    
    Error = gflConvertDDBIntoBitmap(hBitmap, PtrBitmap) 'Convert the DDB in  Gfl_Bitmap
    If Error = GFL_NO_ERROR Then                        'If no error
        extGetGflBitmapFromPtr PtrBitmap, GflBitmap     'Get data
        extShowBitmapOnDCEx GflBitmap, Me.hdc           'And display the bitmap on the DC
    End If
    
    SelectObject hMemoryDC, holdDC                      '
    DeleteDC hMemoryDC                                  'Delete context
    DeleteObject hBitmap                                'Delete fill color
    
    gflFreeBitmapData GflBitmap
End If

If Error <> GFL_NO_ERROR Then MsgBox extGetStr(gflGetErrorString(Error)) 'Display message box
gflLibraryExit 'Quit library
End Sub

