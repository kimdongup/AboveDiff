VERSION 5.00
Begin VB.Form Form7 
   AutoRedraw      =   -1  'True
   Caption         =   "Form7"
   ClientHeight    =   4110
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   5565
   LinkTopic       =   "Form7"
   ScaleHeight     =   4110
   ScaleWidth      =   5565
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form7"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflGetDefaultLoadParams
' gflLoadBitmapFromHandle
' gflFreeBitmap
'
' gflLibraryInit
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extGetStr
' extFarProc
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
'
' Module GflReadData
' ------------------------------

Option Explicit

Dim GflBitmap As GFL_BITMAP

Private Sub Form_Load()
Dim GflLoadParams As GFL_LOAD_PARAMS
Dim GflInfo As GFL_FILE_INFORMATION
Dim PtrBitmap As Long
Dim Error As Integer

gflLibraryInit 'Initialize the library
gflGetDefaultLoadParams GflLoadParams 'Gets default parameters for loading

extLoadFile App.Path & "\image.jpg", RData 'We load the file in RData (copy of the READ_DATA structure)

With GflLoadParams
    .Callbacks.Read = extFarProc(AddressOf READ_ReadFunction) 'Set the callbacks
    .Callbacks.Tell = extFarProc(AddressOf READ_TellFunction)
    .Callbacks.Seek = extFarProc(AddressOf READ_SeekFunction)
    .Flags = GFL_LOAD_SKIP_ALPHA 'no alpha layer
    .Origin = GFL_BOTTOM_LEFT 'origin is top-left
    .ColorModel = GFL_BGR 'component order like DIB
    .LinePadding = 4 'line padding on 4 bytes (32bits)
    .Width = 320
    .Height = 240
    .Offset = 0
    .FormatIndex = -1 'Automatic recognition of the picture format
End With

Error = gflLoadBitmapFromHandle(VarPtr(RData), PtrBitmap, GflLoadParams, GflInfo) 'Read data from memory

If Error = GFL_NO_ERROR Then 'If no error
    extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the picture data
    extShowBitmapOnDc GflBitmap, Me.hdc 'Display bitmap
    gflFreeBitmapData GflBitmap 'Free bitmap
End If

If Error <> GFL_NO_ERROR Then MsgBox "Error : " & extGetStr(gflGetErrorString(Error)) 'Display a message box

gflLibraryExit 'Quit the library
End Sub
