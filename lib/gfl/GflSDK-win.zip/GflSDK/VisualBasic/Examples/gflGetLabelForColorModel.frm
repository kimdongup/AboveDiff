VERSION 5.00
Begin VB.Form Form3 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form3"
   ClientHeight    =   3255
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   4695
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3255
   ScaleWidth      =   4695
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   3255
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   4695
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
' gflGetLabelForColorModel
' gflGetFileInformation
' gflLibraryInit
' gflLibraryExit
'
' GFL_FILE_INFORMATION
'
' ------------------------------

Option Explicit

Private Sub Form_Load()
Dim Infos As GFL_FILE_INFORMATION 'The structure to get file informations
Dim File As String
Dim Index As Integer

File = App.Path & "\image.dcm" 'File to load
Index = -1 'Format index (-1 for automatic recognition)

gflLibraryInit 'Initialize the library
If gflGetFileInformation(File, Index, Infos) = GFL_NO_ERROR Then
    'This function get the color model used
    Text1.text = "The color model is : " & extGetStr(gflGetLabelForColorModel(Infos.ColorModel))
    gflFreeFileInformation Infos
End If
gflLibraryExit 'Quit the library
End Sub

