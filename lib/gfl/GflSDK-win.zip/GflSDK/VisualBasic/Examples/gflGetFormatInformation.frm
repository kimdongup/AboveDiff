VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.Form Form11 
   Caption         =   "Form11"
   ClientHeight    =   6300
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   10455
   LinkTopic       =   "Form11"
   ScaleHeight     =   6300
   ScaleWidth      =   10455
   StartUpPosition =   3  'Windows Default
   Begin MSComctlLib.ListView ListView1 
      Height          =   6255
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   9975
      _ExtentX        =   17595
      _ExtentY        =   11033
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      AllowReorder    =   -1  'True
      FullRowSelect   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   6
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Id"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "Description"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Text            =   "Nom"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   3
         Text            =   "Lecture"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(5) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   4
         Text            =   "Ecriture"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(6) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   5
         Text            =   "Extentions"
         Object.Width           =   2540
      EndProperty
   End
End
Attribute VB_Name = "Form11"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflGetNumberOfFormat
' gflGetFormatInformationByIndex
'
' gflLibraryInit
' gflLibraryExit
'
' extRTN
'
' GFL_FORMAT_INFORMATION
'
' ------------------------------

Option Explicit

Private Sub Form_Load()
Dim FormatID As Integer
Dim SuffixID As Integer
Dim Item As ListItem
Dim FormatInfo As GFL_FORMAT_INFORMATION

gflLibraryInit 'Initialize the library

For FormatID = 0 To gflGetNumberOfFormat - 1 'For each format
    FormatInfo.Description = ""
    FormatInfo.Name = ""
    
    gflGetFormatInformationByIndex FormatID, FormatInfo 'Get informations on the current format
    
        Set Item = ListView1.ListItems.Add(, , FormatInfo.Index) 'Add his index on the array
        Item.SubItems(1) = extRTN(FormatInfo.Description) 'His description
        Item.SubItems(2) = extRTN(FormatInfo.Name) 'His name
        Item.SubItems(3) = IIf(FormatInfo.Status And GFL_READ, "Oui", "Non") 'If readeable
        Item.SubItems(4) = IIf(FormatInfo.Status And GFL_WRITE, "Oui", "Non") 'If writable
        For SuffixID = 0 To FormatInfo.NumberOfExtension - 1 'For each extension
            Item.SubItems(5) = Item.SubItems(5) & extRTN(FormatInfo.Extension(SuffixID)) + " " 'Display the suffix
        Next
Next

gflLibraryExit 'Quit the library
End Sub

Private Sub Form_Resize()
ListView1.Width = Me.ScaleWidth
ListView1.Height = Me.ScaleHeight
End Sub

