VERSION 5.00
Begin VB.Form Form2 
   AutoRedraw      =   -1  'True
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form2"
   ClientHeight    =   4815
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   6975
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4815
   ScaleWidth      =   6975
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Picture1 
      Height          =   4815
      Left            =   1680
      MousePointer    =   2  'Cross
      ScaleHeight     =   4755
      ScaleWidth      =   5235
      TabIndex        =   0
      Top             =   0
      Width           =   5295
   End
   Begin VB.Label Label9 
      AutoSize        =   -1  'True
      Caption         =   "W"
      Height          =   195
      Left            =   120
      TabIndex        =   15
      Top             =   2520
      Width           =   165
   End
   Begin VB.Label Label8 
      AutoSize        =   -1  'True
      Caption         =   "H"
      Height          =   195
      Left            =   120
      TabIndex        =   14
      Top             =   2280
      Width           =   120
   End
   Begin VB.Label labW 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   13
      Top             =   2520
      Width           =   1095
   End
   Begin VB.Label labH 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   12
      Top             =   2280
      Width           =   1095
   End
   Begin VB.Label labPick 
      BorderStyle     =   1  'Fixed Single
      Height          =   495
      Left            =   480
      TabIndex        =   11
      Top             =   1560
      Width           =   495
   End
   Begin VB.Label labB 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   10
      Top             =   1200
      Width           =   1095
   End
   Begin VB.Label labG 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   9
      Top             =   960
      Width           =   1095
   End
   Begin VB.Label labR 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   8
      Top             =   720
      Width           =   1095
   End
   Begin VB.Label labY 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   7
      Top             =   360
      Width           =   1095
   End
   Begin VB.Label labX 
      Caption         =   "0"
      Height          =   255
      Left            =   480
      TabIndex        =   6
      Top             =   120
      Width           =   1095
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      Caption         =   "B"
      Height          =   195
      Left            =   120
      TabIndex        =   5
      Top             =   1200
      Width           =   105
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      Caption         =   "G"
      Height          =   195
      Left            =   120
      TabIndex        =   4
      Top             =   960
      Width           =   120
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "R"
      Height          =   195
      Left            =   120
      TabIndex        =   3
      Top             =   720
      Width           =   120
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Y"
      Height          =   195
      Left            =   120
      TabIndex        =   2
      Top             =   360
      Width           =   105
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "X"
      Height          =   195
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   105
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' This example loads a picture in memory
' Gets a DIB with GDI
' Display on the screen
' With the mouse, we can obtain the color of a pixel

Option Explicit

Dim GflBitmap As GFL_BITMAP

Private Sub Form_Load()
Dim GflParams As GFL_LOAD_PARAMS
Dim PtrBitmap As Long
Dim GflInfo As GFL_FILE_INFORMATION
Dim File As String
Dim Error As Integer

gflLibraryInit
gflGetDefaultLoadParams GflParams

With GflParams
    .Flags = GFL_LOAD_SKIP_ALPHA Or GFL_LOAD_BY_EXTENSION_ONLY
    .Origin = GFL_BOTTOM_LEFT 'Origin is top left
    .ColorModel = GFL_BGR 'Component order like DIB
    .LinePadding = 4 'Line padding on 4 bytes (32bits)
End With

Me.Picture1.AutoRedraw = True
File = App.Path & "\image.jpg"
Error = gflLoadBitmap(File, PtrBitmap, GflParams, GflInfo)
    
    If Error = GFL_NO_ERROR Then
        extGetGflBitmapFromPtr PtrBitmap, GflBitmap
        Error = gflChangeColorDepth(GflBitmap, PtrBitmap, GFL_MODE_TO_16COLORS, GFL_MODE_NO_DITHER)
        If Error = GFL_NO_ERROR Then extGetGflBitmapFromPtr PtrBitmap, GflBitmap
        
        labH.Caption = GflBitmap.Height 'Display height
        labW.Caption = GflBitmap.Width 'And with of the picture
        extShowBitmapOnDc GflBitmap, Picture1.hdc
    End If

If Error <> GFL_NO_ERROR Then MsgBox extGetStr(gflGetErrorString(Error))
End Sub

Private Sub Form_Unload(Cancel As Integer)
gflFreeBitmapData GflBitmap
gflLibraryExit
End Sub

Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim cx As Long
Dim cy As Long
Dim Color As GFL_COLOR 'This structure is to retrieve the color information

cx = ScaleX(x, vbTwips, vbPixels) 'We convert the Twips data in pixels
cy = ScaleY(y, vbTwips, vbPixels)
gflGetColorAt GflBitmap, cx, cy, Color 'We get the pixel value

labX.Caption = cx  'Display values
labY.Caption = cy
labR.Caption = Color.Red
labG.Caption = Color.Green
labB.Caption = Color.Blue

labPick.BackColor = RGB(labR, labG, labB) 'Display color
End Sub
