VERSION 5.00
Begin VB.Form Form5 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form5"
   ClientHeight    =   3135
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   4455
   LinkTopic       =   "Form5"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3135
   ScaleWidth      =   4455
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   3135
      Left            =   0
      MultiLine       =   -1  'True
      TabIndex        =   0
      Top             =   0
      Width           =   4455
   End
End
Attribute VB_Name = "Form5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
' gflFileCreate
' gflFileAddPicture
' gflFileClose
' gflGetDefaultSaveParams
' gflGetFormatIndexByName
' gflGetDefaultLoadParams
' gflLoadBitmap
'
' extGetGflBitmapFromPtr
'
' gflLibraryInit
' gflLibraryExit
'
' GFL_LOAD_PARAMS
' GFL_SAVE_PARAMS
' GFL_FILE_INFORMATION
' GFL_BITMAP
' ------------------------------
Option Explicit

Private Sub Form_Load()
Dim LoadParams As GFL_LOAD_PARAMS
Dim SaveParams As GFL_SAVE_PARAMS
Dim Infos As GFL_FILE_INFORMATION
Dim gflbitmap As GFL_BITMAP
Dim ptrbitmap As Long
Dim Ret As Integer
Dim DstFile As String
Dim SrcFile() As String
Dim Count As Long
Dim Ind As Integer
Dim Handle As Long

DstFile = App.Path & "\image.tif"       'TIFF file to receive picture

ReDim SrcFile(2)
SrcFile(0) = App.Path & "\image.dcm"    'Picture to add
SrcFile(1) = App.Path & "\image.bmp"
SrcFile(2) = App.Path & "\image.jpg"
Count = UBound(SrcFile) + 1

gflLibraryInit 'Initialize the library
gflGetDefaultSaveParams SaveParams 'Get default parameters for saving
SaveParams.FormatIndex = gflGetFormatIndexByName("tiff") 'Get index of TIFF format

Ret = gflFileCreate(Handle, DstFile, Count, SaveParams) 'Create the TIFF file
If Ret = GFL_NO_ERROR Then 'If no error
    Text1.text = Text1.text & "Create " & DstFile & vbCrLf
    For Ind = 0 To Count - 1 'For each picture
        gflGetDefaultLoadParams LoadParams 'Get default parameters for loading
        Ret = gflLoadBitmap(SrcFile(Ind), ptrbitmap, LoadParams, Infos) 'Load the picture
        If Ret = GFL_NO_ERROR Then 'If no error
            extGetGflBitmapFromPtr ptrbitmap, gflbitmap 'Get data in Gfl_Bitmap
            gflFileAddPicture Handle, gflbitmap 'Add picture on TIFF file
            Text1.text = Text1.text & "Adding " & SrcFile(Ind) & vbCrLf
        End If
    Next
    gflFileClose Handle 'Close the TIFF file
    Text1.text = Text1.text & "Close the file"
End If

gflLibraryExit 'Quit the library
End Sub
