Attribute VB_Name = "GflLibExt"
' Graphics File Library Extended
'
' GFL library Copyright (c) 1991-2002 Pierre-e Gougelet
' All rights reserved
' Commercial use is not authorized without agreement
'
' Interface for Visual Basic : J�r�me Quintard (contact@jeromequintard.com)

Option Explicit

'Sert � copier la m�moire entre 2 pointeurs
Private Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByVal lpvDest As Long, ByVal lpvSource As Long, ByVal cbCopy As Long)
'Sert � convertir un pointeur en string
Private Declare Function lstrcpy Lib "kernel32" Alias "lstrcpyA" (ByVal lpString1 As String, ByVal lpString2 As Long) As Long
Private Declare Function lstrlen Lib "kernel32" Alias "lstrlenA" (ByVal lpString As Long) As Long

Private Type BITMAPINFOHEADER
        biSize As Long
        biWidth As Long
        biHeight As Long
        biPlanes As Integer
        biBitCount As Integer
        biCompression As Long
        biSizeImage As Long
        biXPelsPerMeter As Long
        biYPelsPerMeter As Long
        biClrUsed As Long
        biClrImportant As Long
End Type

Private Type RGBQUAD
        rgbBlue As Byte
        rgbGreen As Byte
        rgbRed As Byte
        rgbReserved As Byte
End Type

Private Type BITMAPINFO
        bmiHeader As BITMAPINFOHEADER
        bmiColors(0 To 255) As RGBQUAD
End Type

Private Const BI_RGB = 0&
Private Const CBM_INIT = &H4
Private Const DIB_RGB_COLORS = 0
Private Const SRCCOPY = &HCC0020

Private Declare Function StretchDIBits Lib "gdi32" (ByVal hdc As Long, ByVal x As Long, ByVal y As Long, ByVal dx As Long, ByVal dy As Long, ByVal SrcX As Long, ByVal SrcY As Long, ByVal wSrcWidth As Long, ByVal wSrcHeight As Long, ByVal lpBits As Long, lpBitsInfo As BITMAPINFO, ByVal wUsage As Long, ByVal dwRop As Long) As Long

'Fonction pour transformer le pointeur vers GFL_BITMAP en un autre GFL_BITMAP
'src  = pointeur gflBitmap
'dest = la structure GFL_BITMAP qui re�oit les donn�es
Public Sub extGetGflBitmapFromPtr(ByVal src As Long, ByRef dest As GFL_BITMAP)
    gflFreeBitmapData dest 'On supprime les data de notre image
    CopyMemory VarPtr(dest), src, Len(dest) 'On copie les datas du bitmap temporaire dans notre bitmap
    gflMemoryFree src 'On supprime le bitmap temporaire de la m�moire
	dest.Comment = &H0
	dest.MetaData = &H0
End Sub

'Fonction pour transformer le pointeur vers GFL_COLORMAP en un autre GFL_COLORMAP
'src  = pointeur gflColorMap
'dest = la structure GFL_COLORMAP qui re�oit les donn�es
Public Sub extGetGflColorMapFromPtr(ByVal src As Long, ByRef dest As GFL_COLORMAP)
    CopyMemory VarPtr(dest), src, Len(dest)
End Sub

'Fonction pour retourner les commentaires d'un fichier
'src  = pointeur vers le tableau
'dest = tableau dynamique STRING qui re�oit les donn�es
'nbr  = nombre d'�l�ments � r�cup�rer
Public Sub extGetGflComments(ByVal src As Long, ByRef dst() As String, ByVal nbr As Integer)
Dim PtrComments As Long
Dim NbrComments As Integer
Dim PtrComment  As Long
Dim PosComment  As Integer

PtrComments = src
NbrComments = nbr

ReDim dst(0)
For PosComment = 0 To nbr - 1
  CopyMemory VarPtr(PtrComment), PtrComments, 4
  PtrComments = PtrComments + 4
  ReDim Preserve dst(PosComment)
  dst(PosComment) = extGetStr(PtrComment)
Next PosComment
End Sub

'Fonction pour retourner un string depuis un pointeur
'src = pointeur
Public Function extGetStr(ByVal src As Long)
    Dim dest As String
    Dim lendest As Integer
    lendest = lstrlen(src)
    dest = Space(lendest)
    lstrcpy dest, src
    extGetStr = dest
End Function

'Fonction pour supprimer les caract�res NULL et TRIMMER un string
'src = string
Public Function extRTN(src As String)
    extRTN = Trim(Replace(src, Chr(0), ""))
End Function

'Fonction pour r�cup�rer l'adresse d'un proc�dure, renvoy�e par l'instruction AddressOf
Public Function extFarProc(pfn As Long) As Long
  extFarProc = pfn
End Function

Public Function extShowBitmapOnDc(ByRef bitmap As GFL_BITMAP, ByVal hdc As Long)
Dim DibInfo As BITMAPINFO
    DibInfo = extGetDIBFromBitmap(bitmap)
    StretchDIBits hdc, 0, 0, bitmap.width, bitmap.height, 0, 0, bitmap.width, bitmap.height, bitmap.Data, DibInfo, DIB_RGB_COLORS, SRCCOPY
End Function

Private Function extGetDIBFromBitmap(ByRef bitmap As GFL_BITMAP) As BITMAPINFO
Dim DibInfo As BITMAPINFO
Dim Ret As Integer
Dim ColorMap As GFL_COLORMAP
Dim Ind As Integer

With DibInfo.bmiHeader
    .biSize = Len(DibInfo.bmiHeader) 'La taille de la structure
    .biWidth = bitmap.width 'Largeur du bitmap
    .biHeight = bitmap.height 'Hauteur du bitmap
    .biPlanes = 1 'Nombre de plans
    .biClrUsed = 0 'Toujours 0
    .biBitCount = 24 'Toujours 24Bits pour l'instant
    .biCompression = BI_RGB 'Toujours BI_RGB
    .biSizeImage = ((bitmap.width * 3 + 3) And &HFFFFFFFC) * bitmap.height 'Taille de l'image
    .biClrImportant = 0 'Toujours 0
End With

If bitmap.Type <> GFL_BINARY And bitmap.Type <> GFL_GREY And bitmap.Type <> GFL_COLORS Then extGetDIBFromBitmap = DibInfo: Exit Function

With DibInfo
    .bmiHeader.biBitCount = 8
    Select Case bitmap.Type 'Suivant le type de bitmap
        Case GFL_COLORS 'Si GFL_COLORS (une palette de couleurs index� de 0 � 255)
            extGetGflColorMapFromPtr bitmap.ColorMap, ColorMap 'On r�cup�re les index du bitmap dans une structure GflColorMap
            For Ind = 0 To 255 'Pour chaque index on indique � la structure Dib_Info
                .bmiColors(Ind).rgbBlue = ColorMap.Blue(Ind) 'La valeur du bleu
                .bmiColors(Ind).rgbGreen = ColorMap.Green(Ind) 'La valeur du vert
                .bmiColors(Ind).rgbRed = ColorMap.Red(Ind) 'La valeur du rouge
            Next Ind
        Case GFL_BINARY 'Si GFL_BINARY (seulement noir et blanc donc 2 couleurs index�s) on indique � Dib_Info qu'il y a deux index
            .bmiColors(0).rgbBlue = 0: .bmiColors(0).rgbGreen = 0: .bmiColors(0).rgbRed = 0 'Le premier vaut Red=0,Green=0,Blue=0 donc du noir (#000000)
            .bmiColors(1).rgbBlue = 255: .bmiColors(1).rgbGreen = 255: .bmiColors(1).rgbRed = 255 'Le second vaut Red=255,Green=255,Blue=255 donc blanc (#FFFFFF)
        Case GFL_GREY 'Si GFL_GREY (On travaille sur 256 nuances)
            For Ind = 0 To 255 'Pour chaque index de Dib_Info on indique une nuance de gris
                .bmiColors(Ind).rgbBlue = Ind  ' Il y a 256 index et 256 gris on donne � chaque index
                .bmiColors(Ind).rgbGreen = Ind ' et pour chaque canaux la valeur de la nuance
                .bmiColors(Ind).rgbRed = Ind
            Next Ind
    End Select
End With
extGetDIBFromBitmap = DibInfo
End Function

