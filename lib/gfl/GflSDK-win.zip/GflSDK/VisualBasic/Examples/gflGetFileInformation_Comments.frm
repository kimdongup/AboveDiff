VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form1"
   ClientHeight    =   5175
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   6495
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5175
   ScaleWidth      =   6495
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   5175
      Left            =   0
      MultiLine       =   -1  'True
      TabIndex        =   0
      Top             =   0
      Width           =   6495
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
' gflGetLabelForColorModel
' gflGetFileInformation
' gflLibraryInit
' gflLibraryExit
' gflFreeFileInformation
'
' GFL_FILE_INFORMATION
'
' extGetGflComments
' ------------------------------

Option Explicit

Private Sub Form_Load()
Dim Infos As GFL_FILE_INFORMATION 'The structure to retrieve informations of the file
Dim File As String
Dim Ret As Integer
Dim Index As Integer
Dim Comments() As String 'The array for the comments
Dim Ind As Integer

File = App.Path & "\image.dcm" 'File to load
Index = -1 'Format index (-1 for automatic recognition)

gflLibraryInit 'Initialize the library
If gflGetFileInformation(File, Index, Infos) = GFL_NO_ERROR Then
    'This function retrieves the comments and put them
    'in the dynamic STRING array
    extGetGflComments Infos.Comment, Comments, Infos.NumberOfComment
    
    For Ind = 0 To UBound(Comments) - 1 'For each entry in the array
        Text1.text = Text1.text & Comments(Ind) & vbCrLf  'Display comment...
    Next
    gflFreeFileInformation Infos 'Free content of GFL_FILE_INFORMATION structure
End If
gflLibraryExit 'Quit the library
End Sub

