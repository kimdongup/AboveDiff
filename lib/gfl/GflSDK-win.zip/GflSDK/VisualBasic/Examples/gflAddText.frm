VERSION 5.00
Begin VB.Form Form8 
   Caption         =   "Form8"
   ClientHeight    =   4680
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   7110
   LinkTopic       =   "Form8"
   ScaleHeight     =   4680
   ScaleWidth      =   7110
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form8"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflGetDefaultLoadParams
' gflLoadBitmap
' gflFreeBitmap
' gflAddText
'
' gflLibraryInit
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extShowBitmapOnDC
' extGetStr
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
' GFL_COLOR
'
' ------------------------------

Option Explicit

Private Sub Form_Load()
Dim GflBitmap As GFL_BITMAP
Dim GflParams As GFL_LOAD_PARAMS
Dim PtrBitmap As Long
Dim GflInfo As GFL_FILE_INFORMATION
Dim File As String
Dim Error As Integer

Dim Txt As String
Dim FontName As String
Dim FontSize As Long
Dim FontBold As Boolean
Dim FontItalic As Boolean
Dim FontStrikeOut As Boolean
Dim FontUnderline As Boolean
Dim FontColor As GFL_COLOR

gflLibraryInit
gflGetDefaultLoadParams GflParams

With GflParams
    .Flags = GFL_LOAD_SKIP_ALPHA Or GFL_LOAD_BY_EXTENSION_ONLY
    .Origin = GFL_BOTTOM_LEFT 'Origin is bottom-left
    .ColorModel = GFL_BGR 'Component order like DIB
    .LinePadding = 4 'Line padding on 4 bytes (32bits)
End With

File = App.Path & "\image.jpg"
Error = gflLoadBitmap(File, PtrBitmap, GflParams, GflInfo) 'Load picture
Me.AutoRedraw = True 'Form must be refreshed
    
    If Error = GFL_NO_ERROR Then 'If no error
        extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the data
                
        Txt = "gflAddText"    'The text...
        FontName = "Verdana"  'The font
        FontSize = "50"       'The size of font
        FontBold = True
        FontItalic = False
        FontStrikeOut = False
        FontUnderline = False
        FontColor.Blue = 0 'Font color
        FontColor.Green = 0
        FontColor.Red = 255
        'Add text in bitmap
        Error = gflAddText(GflBitmap, Txt, FontName, 10, 10, FontSize, 0, CByte(FontItalic), CByte(FontBold), CByte(FontStrikeOut), CByte(FontUnderline), CByte(True), FontColor)
        
        extShowBitmapOnDc GflBitmap, Me.hdc 'Display bitmap
        gflFreeBitmapData GflBitmap 'Free bitmap
    End If

If Error <> GFL_NO_ERROR Then MsgBox extGetStr(gflGetErrorString(Error)) 'Display a message box
gflLibraryExit 'Quit the library
End Sub

