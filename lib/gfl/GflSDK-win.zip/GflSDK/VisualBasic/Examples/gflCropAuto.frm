VERSION 5.00
Begin VB.Form Form12 
   Caption         =   "Form12"
   ClientHeight    =   4110
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   7950
   LinkTopic       =   "Form12"
   ScaleHeight     =   4110
   ScaleWidth      =   7950
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Picture2 
      Height          =   4095
      Left            =   4080
      ScaleHeight     =   4035
      ScaleWidth      =   3795
      TabIndex        =   1
      Top             =   0
      Width           =   3855
   End
   Begin VB.PictureBox Picture1 
      Height          =   4095
      Left            =   0
      ScaleHeight     =   4035
      ScaleWidth      =   3915
      TabIndex        =   0
      Top             =   0
      Width           =   3975
   End
End
Attribute VB_Name = "Form12"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflLoadBitmap
' gflLibraryInit
' gflGetDefaultLoadParams
' gflClone
' gflAutoCrop
' gflEnableLZW
' gflFreeBitmap
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extShowBitmapOnDc
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
' GFL_COLOR
'
' ------------------------------

Private Sub Form_Load()
Dim GflBitmap1 As GFL_BITMAP, GflBitmap2 As GFL_BITMAP
Dim PtrBitmap1 As Long, PtrBitmap2 As Long
Dim Error As Integer
Dim LoadParams As GFL_LOAD_PARAMS
Dim FileInfo As GFL_FILE_INFORMATION


gflLibraryInit 'Initialize the library
gflGetDefaultLoadParams LoadParams 'On charge les param�tres de chargement par d�faut

With LoadParams
    .Flags = GFL_LOAD_SKIP_ALPHA 'No alpha layer
    .ColorModel = GFL_BGR 'Component order like DIB
    .Origin = GFL_BOTTOM_LEFT 'Origin is bottom-left
    .LinePadding = 4 'Line padding on 4 bytes (32bits)
End With
Picture1.AutoRedraw = True
Picture2.AutoRedraw = True

If gflLoadBitmap(App.Path & "\image2.bmp", PtrBitmap1, LoadParams, FileInfo) = GFL_NO_ERROR Then 'Load picture
    extGetGflBitmapFromPtr PtrBitmap1, GflBitmap1 'If no error get data on GflBitmap1
    extShowBitmapOnDc GflBitmap1, Picture1.hdc 'Display picture on the DC
    
    PtrBitmap2 = gflCloneBitmap(GflBitmap1) 'Clone bitmap
    If PtrBitmap2 <> &H0 Then 'If it is good
        extGetGflBitmapFromPtr PtrBitmap2, GflBitmap2 'Get data on GflBitmap2
        
        Dim Color As GFL_COLOR 'Background color
        Color.Red = 0
        Color.Blue = 0
        Color.Green = 0
        'The Color parameter of AutoCrop function is declared ByRef Color as GFL_COLOR
        'it is possible to declare it ByRef Color as Any
        'So it is possible to use AutoCrop with the color parameter as &h0 (NULL)
        'AutoCrop use the pixel color of pixel 0,0 pto know the background color
        If gflAutoCrop(GflBitmap2, PtrBitmap2, Color, 32) = GFL_NO_ERROR Then 'AutoCrop of picture
            extGetGflBitmapFromPtr PtrBitmap2, GflBitmap2 'If no error get data on GflBitmap2
        End If
        
        extShowBitmapOnDc GflBitmap2, Picture2.hdc 'Display picture on the DC
        gflFreeBitmapData GflBitmap2 'Free GflBitmap2
    End If
    
    gflFreeBitmapData GflBitmap1 'Free GflBitmap1
Else
    MsgBox "Error loading...", vbExclamation 'Display a message box
End If

gflLibraryExit 'Quit the library
End Sub

