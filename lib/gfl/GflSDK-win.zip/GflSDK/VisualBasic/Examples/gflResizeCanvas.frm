VERSION 5.00
Begin VB.Form Form10 
   Caption         =   "Form10"
   ClientHeight    =   7950
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   8220
   LinkTopic       =   "Form10"
   ScaleHeight     =   7950
   ScaleWidth      =   8220
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form10"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------
' This example use :
' ------------------------------
'
' gflGetDefaultLoadParams
' gflGetDefaultSaveParams
' gflLoadBitmap
' gflFreeBitmap
' gflChangeColorDepth
' gflResizeCanvas
' gflGetFormatIndexByName
'
' gflLibraryInit
' gflLibraryExit
'
' extGetGflBitmapFromPtr
' extShowBitmapOnDC
' extGetStr
'
' GFL_BITMAP
' GFL_LOAD_PARAMS
' GFL_FILE_INFORMATION
' GFL_SAVE_PARAMS
' GFL_COLOR
'
' ------------------------------

Private Sub Form_Load()
Dim GflBitmap As GFL_BITMAP
Dim GflLoadParams As GFL_LOAD_PARAMS
Dim GflSaveParams As GFL_SAVE_PARAMS
Dim GflInfo As GFL_FILE_INFORMATION
Dim PtrBitmap As Long
Dim Error As Integer
Dim File As String, FileDest As String

Dim Color As GFL_COLOR
Dim NewWidth As Long
Dim NewHeight As Long

gflLibraryInit 'Initialize the library
gflGetDefaultLoadParams GflLoadParams 'Gets default parameters for loading
gflEnableLZW True 'Activate the LZW compression

With GflLoadParams
    .Flags = GFL_LOAD_SKIP_ALPHA Or GFL_LOAD_BY_EXTENSION_ONLY
    .Origin = GFL_BOTTOM_LEFT 'Origin is bottom-left
    .ColorModel = GFL_BGR 'Component order like DIB
    .LinePadding = 4 'Line padding on 4 bytes (32bits)
End With

File = App.Path & "\image.jpg"
FileDest = App.Path & "\result.gif"

Me.AutoRedraw = True 'Form must be refreshed
Error = gflLoadBitmap(File, PtrBitmap, GflLoadParams, GflInfo) 'Load picture
If Error = GFL_NO_ERROR Then 'If no error
    extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the data
    
    NewWidth = GflBitmap.Width + 4 'New width
    NewHeight = GflBitmap.Height + 4 'New height
    Color.Alpha = 0 'Background color
    Color.Blue = 0
    Color.Green = 0
    Color.Red = 255
    
    Error = gflResizeCanvas(GflBitmap, PtrBitmap, NewWidth, NewHeight, GFL_CANVASRESIZE_CENTER, Color) 'Resize the picture
    If Error = GFL_NO_ERROR Then 'If no error
        extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the picture data
        extShowBitmapOnDc GflBitmap, Me.hdc 'Draw the bitmap (optional)
        
        Error = gflChangeColorDepth(GflBitmap, PtrBitmap, GFL_MODE_TO_32COLORS, GFL_MODE_NO_DITHER) 'Change color depth of the picture
        If Error = GFL_NO_ERROR Then 'Si aucune erreur
            extGetGflBitmapFromPtr PtrBitmap, GflBitmap 'Get the picture data
            
            gflGetDefaultSaveParams GflSaveParams 'Gets default parameters for saving
            With GflSaveParams
                .Flags = GFL_SAVE_REPLACE_EXTENSION
                .FormatIndex = gflGetFormatIndexByName("gif") 'Get the index of GIF format
                .Interlaced = True 'Entrelaced GIF
            End With
            Error = gflSaveBitmap(FileDest, GflBitmap, GflSaveParams) 'Save the picture
            
            gflFreeBitmapData GflBitmap 'Free bitmap
        End If
    End If
End If

If Error <> GFL_NO_ERROR Then MsgBox extGetStr(gflGetErrorString(Error)) 'Display a message box
gflLibraryExit 'Quit the library
End Sub
