VERSION 5.00
Begin VB.Form Main 
   Caption         =   "Form5"
   ClientHeight    =   5775
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   9930
   LinkTopic       =   "Form5"
   ScaleHeight     =   5775
   ScaleWidth      =   9930
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Example 14"
      Height          =   975
      Index           =   13
      Left            =   6720
      TabIndex        =   26
      Top             =   3480
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 13"
      Height          =   975
      Index           =   12
      Left            =   6720
      TabIndex        =   24
      Top             =   2400
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 12"
      Height          =   975
      Index           =   11
      Left            =   6720
      TabIndex        =   22
      Top             =   1320
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 11"
      Height          =   975
      Index           =   10
      Left            =   6720
      TabIndex        =   10
      Top             =   240
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 10"
      Height          =   975
      Index           =   9
      Left            =   3480
      TabIndex        =   9
      Top             =   4560
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 9"
      Height          =   975
      Index           =   8
      Left            =   3480
      TabIndex        =   8
      Top             =   3480
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 5"
      Height          =   975
      Index           =   4
      Left            =   240
      TabIndex        =   7
      Top             =   4560
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 4"
      Height          =   975
      Index           =   3
      Left            =   240
      TabIndex        =   6
      Top             =   3480
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 2"
      Height          =   975
      Index           =   1
      Left            =   240
      TabIndex        =   5
      Top             =   1320
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 8"
      Height          =   975
      Index           =   7
      Left            =   3480
      TabIndex        =   4
      Top             =   2400
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 7"
      Height          =   975
      Index           =   6
      Left            =   3480
      TabIndex        =   3
      Top             =   1320
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 6"
      Height          =   975
      Index           =   5
      Left            =   3480
      TabIndex        =   2
      Top             =   240
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 3"
      Height          =   975
      Index           =   2
      Left            =   240
      TabIndex        =   1
      Top             =   2400
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 1"
      Height          =   975
      Index           =   0
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   975
   End
   Begin VB.Label Label14 
      Caption         =   "Load a GIF picture and display it with a transparency color"
      Height          =   855
      Left            =   7920
      TabIndex        =   27
      Top             =   3600
      Width           =   1815
   End
   Begin VB.Label Label13 
      Caption         =   "Load 2 pictues and copies them in a third."
      Height          =   855
      Left            =   7920
      TabIndex        =   25
      Top             =   2520
      Width           =   1815
   End
   Begin VB.Label Label12 
      Caption         =   "Load a picture, clone it and crop his copy"
      Height          =   855
      Left            =   7920
      TabIndex        =   23
      Top             =   1440
      Width           =   1815
   End
   Begin VB.Label Label11 
      Caption         =   "Obtain informations about supported formats in GflLib"
      Height          =   855
      Left            =   7920
      TabIndex        =   21
      Top             =   360
      Width           =   1815
   End
   Begin VB.Label Label10 
      Caption         =   "Change the size of the picture, display it in a window and save it in GIF format"
      Height          =   855
      Left            =   4680
      TabIndex        =   20
      Top             =   4680
      Width           =   1815
   End
   Begin VB.Label Label9 
      Caption         =   "Explanation to convert an image between different devices"
      Height          =   855
      Left            =   4680
      TabIndex        =   19
      Top             =   3600
      Width           =   1815
   End
   Begin VB.Label Label8 
      Caption         =   "Add a text on the picture and display the result"
      Height          =   855
      Left            =   4680
      TabIndex        =   18
      Top             =   2520
      Width           =   1815
   End
   Begin VB.Label Label7 
      Caption         =   "Load a picture in memory with callback functions"
      Height          =   735
      Left            =   4680
      TabIndex        =   17
      Top             =   1440
      Width           =   1815
   End
   Begin VB.Label Label6 
      Caption         =   "Load a picture and save it from memory with callback functions"
      Height          =   855
      Left            =   4680
      TabIndex        =   16
      Top             =   360
      Width           =   1815
   End
   Begin VB.Label Label5 
      Caption         =   "Create a TIFF multi-page picture, and add some pictures"
      Height          =   855
      Left            =   1440
      TabIndex        =   15
      Top             =   4680
      Width           =   1815
   End
   Begin VB.Label Label4 
      Caption         =   "Apply a 90� lossless rotation on a JPEG file"
      Height          =   855
      Left            =   1440
      TabIndex        =   14
      Top             =   3600
      Width           =   1815
   End
   Begin VB.Label Label3 
      Caption         =   "Get color model of a picture"
      Height          =   855
      Left            =   1440
      TabIndex        =   13
      Top             =   2520
      Width           =   1815
   End
   Begin VB.Label Label2 
      Caption         =   "Load and display a picture in a window. Get the color according to the coordinates."
      Height          =   855
      Left            =   1440
      TabIndex        =   12
      Top             =   1440
      Width           =   1815
   End
   Begin VB.Label Label1 
      Caption         =   "Get comments from a picture"
      Height          =   855
      Left            =   1440
      TabIndex        =   11
      Top             =   360
      Width           =   1815
   End
End
Attribute VB_Name = "Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click(Index As Integer)
Select Case Index
    Case 0: Form1.Show 1
    Case 1: Form2.Show 1
    Case 2: Form3.Show 1
    Case 3: Form4.Show 1
    Case 4: Form5.Show 1
    Case 5: Form6.Show 1
    Case 6: Form7.Show 1
    Case 7: Form8.Show 1
    Case 8: Form9.Show 1
    Case 9: Form10.Show 1
    Case 10: Form11.Show 1
    Case 11: Form12.Show 1
    Case 12: Form13.Show 1
    Case 13: Form14.Show 1
End Select
End Sub

