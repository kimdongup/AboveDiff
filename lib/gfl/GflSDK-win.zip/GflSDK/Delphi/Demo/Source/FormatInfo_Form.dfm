object FormatInfoForm: TFormatInfoForm
  Left = 237
  Top = 154
  BorderStyle = bsToolWindow
  BorderWidth = 5
  Caption = 'FormatInfo'
  ClientHeight = 503
  ClientWidth = 774
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  Scaled = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Splitter1: TSplitter
    Left = 519
    Top = 0
    Width = 4
    Height = 503
    Cursor = crHSplit
  end
  object ListView: TListView
    Left = 0
    Top = 0
    Width = 519
    Height = 503
    Align = alLeft
    Columns = <
      item
        Caption = 'Image Format'
        Width = 180
      end
      item
        Alignment = taCenter
        Caption = 'Read'
        Width = 38
      end
      item
        Alignment = taCenter
        Caption = 'Write'
        Width = 40
      end
      item
        Caption = 'Extensions'
        Width = 240
      end>
    GridLines = True
    HotTrack = True
    HotTrackStyles = [htUnderlineCold]
    RowSelect = True
    TabOrder = 0
    ViewStyle = vsReport
  end
  object ListViewError: TListView
    Left = 523
    Top = 0
    Width = 251
    Height = 503
    Align = alClient
    Columns = <
      item
        Caption = 'Error#'
        Width = 45
      end
      item
        Caption = 'String'
        Width = 200
      end>
    HotTrackStyles = [htUnderlineCold]
    RowSelect = True
    TabOrder = 1
    ViewStyle = vsReport
  end
end
