program GFL_SDK_Demo;

uses
  Forms, LibGfl,
  FormatInfo_Form in 'FormatInfo_Form.pas' {FormatInfoForm},
  ImageView_Form in 'ImageView_Form.pas' {ImageViewForm};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TImageViewForm, ImageViewForm);
  Application.CreateForm(TFormatInfoForm, FormatInfoForm);
  Application.Run;
end.
