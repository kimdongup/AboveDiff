unit FormatInfo_Form;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls, ExtCtrls;

type
  TFormatInfoForm = class(TForm)
    ListView: TListView;
    ListViewError: TListView;
    Splitter1: TSplitter;
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
  public
    Filter : String;
  end;

var FormatInfoForm: TFormatInfoForm;


var GflFilterString : String; // FilterString for Open+Save DialogBoxes

//******************************************************************************
implementation
uses LibGfl;
{$R *.DFM}

//------------------------------------------------------------------------------
procedure GetFilterString;
var f,i,j : Integer;
    filter, ext : String;
    info : TGFL_FORMAT_INFORMATION;
    sl : TStringList;

begin
  sl := TStringlist.Create;
  f := gflGetNumberOfFormat;
  for i := 0 to f-1 do begin
      filter := '';
      gflGetFormatInformationByIndex(i, info);
      ext := gflGetDefaultFormatSuffixByIndex(i);
      if ext = '' then ext := '*';
      filter := Format('%s|%s (*.%s)|',[filter, info.Description, ext]);

      // Extensions
      if info.NumberOfExtension > 0 then begin
         for j := 0 to info.NumberOfExtension-1 do
             filter := filter + '*.' + info.Extension[j] + ';';
         delete(filter, Length(filter), 1);
      end else
         filter := filter + '*.*';

      sl.Add(filter);
  end;

  // create sorted FilterString
  sl.Sort;
  GflFilterString := 'All files (*.*)|*.*';
  for i := 0 to sl.Count-1 do
      GflFilterString := GflFilterString  + sl[i];
  sl.Free;
end;

//------------------------------------------------------------------------------
procedure TFormatInfoForm.FormCreate(Sender: TObject);
var f,i,j : Integer;
    s,d,e : String;
    r,w : GFL_Bool;
    sl : TStringList;
    info : TGFL_FORMAT_INFORMATION;
begin
  // Version Info
  Caption := 'GFL SDK Version ' + gflGetVersion;

  // Format Infos
  f := gflGetNumberOfFormat;
  sl := TStringList.Create;

  Filter := 'All files (*.*)|*.*';
  for i := 0 to f-1 do begin
      // Description
      d := gflGetFormatDescriptionByIndex(i);

      // Read, Write ?
      w := gflFormatIsWritableByIndex(i);
      r := gflFormatIsReadableByIndex(i);
      sl.Clear;
      if Boolean(r) then sl.Add('Yes') else sl.Add('No');
      if Boolean(w) then sl.Add('Yes') else sl.Add('No');

      // Extensions
      gflGetFormatInformationByIndex(i, info);
      e := '';
      for j := 0 to info.NumberOfExtension-1 do
          e := e + info.Extension[j] + ', ';
      delete(e,Length(e)-1,1);
      sl.Add(e);

      // Add Info to ListView
      ListView.Items.Add;
      ListView.Items[ListView.Items.Count-1].Caption := d;
      ListView.Items[ListView.Items.Count-1].SubItems.Assign(sl);

  end;

  // Sort ListView
  ListView.SortType := stText;

  // Error Strings
  for i := 0 to 255 do begin
      s := gflGetErrorString(i);
      // if Error exsits
      if copy(s,1,1) <> '?' then begin
         sl.Clear;
         sl.Add(s);
         ListViewError.Items.Add;
         ListViewError.Items[ListViewError.Items.Count-1].Caption := Format('%.3d',[i]);
         ListViewError.Items[ListViewError.Items.Count-1].SubItems.Assign(sl);
      end;
  end;

  sl.free;
end;

//******************************************************************************
initialization
  GetFilterString;
end.
