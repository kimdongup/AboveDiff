object ImageViewForm: TImageViewForm
  Left = 285
  Top = 217
  Width = 678
  Height = 520
  HorzScrollBar.Smooth = True
  HorzScrollBar.Size = 12
  HorzScrollBar.Style = ssFlat
  HorzScrollBar.Tracking = True
  VertScrollBar.Smooth = True
  VertScrollBar.Size = 12
  VertScrollBar.Style = ssFlat
  VertScrollBar.Tracking = True
  Caption = 'LibGfl Demo'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Menu = MainMenu
  OldCreateOrder = False
  Position = poScreenCenter
  Scaled = False
  PixelsPerInch = 96
  TextHeight = 13
  object Image: TImage
    Left = 0
    Top = 0
    Width = 160
    Height = 120
    AutoSize = True
  end
  object MainMenu: TMainMenu
    Left = 232
    Top = 32
    object File1: TMenuItem
      Caption = 'File'
      object Open1: TMenuItem
        Caption = 'Open'
        OnClick = Open1Click
      end
      object N1: TMenuItem
        Caption = '-'
      end
      object Exit1: TMenuItem
        Caption = 'Exit'
        OnClick = ExitClick
      end
    end
    object Formats1: TMenuItem
      Caption = 'Format-Info'
      OnClick = Formats1Click
    end
    object Help1: TMenuItem
      Caption = 'Help'
      object About1: TMenuItem
        Caption = 'About'
        OnClick = About1Click
      end
    end
  end
  object OpenDialog: TOpenDialog
    Options = [ofReadOnly, ofHideReadOnly, ofPathMustExist, ofFileMustExist, ofEnableSizing]
    Title = 'Select a bitmap to load'
    Left = 232
    Top = 80
  end
end
