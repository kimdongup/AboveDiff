VERSION 5.00
Begin VB.Form Form5 
   Caption         =   "Form5"
   ClientHeight    =   4725
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   8325
   LinkTopic       =   "Form5"
   ScaleHeight     =   4725
   ScaleWidth      =   8325
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Picture2 
      Height          =   3735
      Left            =   3720
      ScaleHeight     =   3675
      ScaleWidth      =   3795
      TabIndex        =   1
      Top             =   0
      Width           =   3855
   End
   Begin VB.PictureBox Picture1 
      Height          =   3735
      Left            =   0
      ScaleHeight     =   3675
      ScaleWidth      =   3555
      TabIndex        =   0
      Top             =   0
      Width           =   3615
   End
End
Attribute VB_Name = "Form5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Ctrl(1) As GflAx.GflAx

Private Sub Form_Load()
Set Ctrl(0) = New GflAx.GflAx
    Ctrl(0).LoadBitmap App.Path & "\image.jpg" 'Load the file
    Ctrl(0).Negative        'Negative the picture

    Picture1.Picture = Ctrl(0).GetPicture 'Display in the picture control

Set Ctrl(1) = Ctrl(0).Clone 'Clone the first object in the second
    Ctrl(1).Negative        'Negative the picture again

    Picture2.Picture = Ctrl(1).GetPicture
End Sub

Private Sub Form_Unload(Cancel As Integer)
Set Ctrl(0) = Nothing 'Remove object instance
Set Ctrl(1) = Nothing
End Sub


