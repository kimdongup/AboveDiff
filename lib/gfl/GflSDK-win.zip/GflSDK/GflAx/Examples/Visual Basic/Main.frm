VERSION 5.00
Begin VB.Form Main 
   Caption         =   "Form5"
   ClientHeight    =   3615
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   6630
   LinkTopic       =   "Form5"
   ScaleHeight     =   3615
   ScaleWidth      =   6630
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Example 6"
      Height          =   975
      Index           =   5
      Left            =   3360
      TabIndex        =   10
      Top             =   2520
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 5"
      Height          =   975
      Index           =   4
      Left            =   120
      TabIndex        =   8
      Top             =   2520
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 1"
      Height          =   975
      Index           =   0
      Left            =   120
      TabIndex        =   3
      Top             =   120
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 3"
      Height          =   975
      Index           =   2
      Left            =   3360
      TabIndex        =   2
      Top             =   120
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 4"
      Height          =   975
      Index           =   3
      Left            =   3360
      TabIndex        =   1
      Top             =   1320
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Example 2"
      Height          =   975
      Index           =   1
      Left            =   120
      TabIndex        =   0
      Top             =   1320
      Width           =   975
   End
   Begin VB.Label Label4 
      Caption         =   "Load a picture, apply effects with the Refresh event use"
      Height          =   855
      Left            =   4560
      TabIndex        =   11
      Top             =   2520
      Width           =   1815
   End
   Begin VB.Label Label3 
      Caption         =   "Load picture, clone it and display the 2 pictures"
      Height          =   855
      Left            =   1320
      TabIndex        =   9
      Top             =   2640
      Width           =   1815
   End
   Begin VB.Label Label1 
      Caption         =   "Load a picture, display it on Picture control and allow to get the pixel color"
      Height          =   975
      Left            =   1320
      TabIndex        =   7
      Top             =   120
      Width           =   1815
   End
   Begin VB.Label Label2 
      Caption         =   "Load a picture, change the color depth, flip it, resize his canvas, and display it"
      Height          =   1215
      Left            =   1320
      TabIndex        =   6
      Top             =   1320
      Width           =   1935
   End
   Begin VB.Label Label6 
      Caption         =   "Load a picture, resize it with keeping his ratio, add a text"
      Height          =   855
      Left            =   4560
      TabIndex        =   5
      Top             =   120
      Width           =   1815
   End
   Begin VB.Label Label7 
      Caption         =   "Load a picture, modify orientation and save it in JPEG format"
      Height          =   855
      Left            =   4560
      TabIndex        =   4
      Top             =   1320
      Width           =   1815
   End
End
Attribute VB_Name = "Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click(Index As Integer)
Select Case Index
    Case 0: Form1.Show 1
    Case 1: Form2.Show 1
    Case 2: Form3.Show 1
    Case 3: Form4.Show 1
    Case 4: Form5.Show 1
    Case 5: Form6.Show 1
End Select
End Sub


