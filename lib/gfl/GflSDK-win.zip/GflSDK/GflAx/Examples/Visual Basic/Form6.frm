VERSION 5.00
Begin VB.Form Form6 
   Caption         =   "Form6"
   ClientHeight    =   5085
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   6990
   LinkTopic       =   "Form6"
   ScaleHeight     =   5085
   ScaleWidth      =   6990
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Test3"
      Height          =   495
      Index           =   2
      Left            =   5160
      TabIndex        =   3
      Top             =   1320
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Test2"
      Height          =   495
      Index           =   1
      Left            =   5160
      TabIndex        =   2
      Top             =   720
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Test1"
      Height          =   495
      Index           =   0
      Left            =   5160
      TabIndex        =   1
      Top             =   120
      Width           =   1215
   End
   Begin VB.PictureBox Picture1 
      Height          =   4215
      Left            =   0
      ScaleHeight     =   4155
      ScaleWidth      =   4875
      TabIndex        =   0
      Top             =   0
      Width           =   4935
   End
End
Attribute VB_Name = "Form6"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Dim WithEvents Ctrl As GflAx.GflAx
Dim Ctrl As GflAx.GflAx

Private Sub Ctrl_Refresh()
Picture1.Picture = Ctrl.GetPicture 'Display in the picture control
End Sub

Private Sub Form_Load()
Set Ctrl = New GflAx.GflAx
    Ctrl.LoadBitmap App.Path & "\image.jpg" 'Load the file
End Sub

Private Sub Command1_Click(Index As Integer)
Select Case Index
    Case 0: Ctrl.Negative
            Ctrl_Refresh
    Case 1: Ctrl.FlipVertical
            Ctrl_Refresh
    Case 2: Ctrl.Rotate 90
            Ctrl_Refresh
End Select
End Sub


Private Sub Form_Unload(Cancel As Integer)
Set Ctrl = Nothing 'Remove object instance
End Sub



