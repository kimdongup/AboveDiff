VERSION 5.00
Begin VB.Form Form4 
   Caption         =   "Form4"
   ClientHeight    =   4530
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   6120
   LinkTopic       =   "Form4"
   ScaleHeight     =   4530
   ScaleWidth      =   6120
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
Dim Ctrl As GflAx.GflAx
Set Ctrl = New GflAx.GflAx

Dim newWidth As Long
Dim newHeight As Long

With Ctrl
    .LoadBitmap App.Path & "\image.jpg" 'Load the file
    .Rotate 90 'Rotation of 90�
    .SaveFormat = AX_JPEG 'Save in JPEG format
    .SaveJPEGProgressive = True 'Progressive
    .SaveJPEGQuality = 70 'Quality of 70%
    .SaveBitmap App.Path & "\result.jpg"
    Me.Picture = .GetPicture 'Display picture
End With

Set Ctrl = Nothing
End Sub

