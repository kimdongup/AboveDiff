VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4815
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   6855
   LinkTopic       =   "Form1"
   ScaleHeight     =   4815
   ScaleWidth      =   6855
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Picture1 
      Height          =   4815
      Left            =   1560
      MousePointer    =   2  'Cross
      ScaleHeight     =   4755
      ScaleWidth      =   5235
      TabIndex        =   0
      Top             =   0
      Width           =   5295
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "X"
      Height          =   195
      Left            =   0
      TabIndex        =   9
      Top             =   120
      Width           =   105
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Y"
      Height          =   195
      Left            =   0
      TabIndex        =   8
      Top             =   360
      Width           =   105
   End
   Begin VB.Label labX 
      Caption         =   "0"
      Height          =   255
      Left            =   360
      TabIndex        =   7
      Top             =   120
      Width           =   1095
   End
   Begin VB.Label labY 
      Caption         =   "0"
      Height          =   255
      Left            =   360
      TabIndex        =   6
      Top             =   360
      Width           =   1095
   End
   Begin VB.Label labPick 
      BorderStyle     =   1  'Fixed Single
      Height          =   495
      Left            =   360
      TabIndex        =   5
      Top             =   720
      Width           =   495
   End
   Begin VB.Label labH 
      Caption         =   "0"
      Height          =   255
      Left            =   360
      TabIndex        =   4
      Top             =   1440
      Width           =   1095
   End
   Begin VB.Label labW 
      Caption         =   "0"
      Height          =   255
      Left            =   360
      TabIndex        =   3
      Top             =   1680
      Width           =   1095
   End
   Begin VB.Label Label8 
      AutoSize        =   -1  'True
      Caption         =   "H"
      Height          =   195
      Left            =   0
      TabIndex        =   2
      Top             =   1440
      Width           =   120
   End
   Begin VB.Label Label9 
      AutoSize        =   -1  'True
      Caption         =   "W"
      Height          =   195
      Left            =   0
      TabIndex        =   1
      Top             =   1680
      Width           =   165
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Ctrl As GflAx.GflAx

Private Sub Form_Load()
Set Ctrl = New GflAx.GflAx

With Ctrl
    .LoadBitmap App.Path & "\image.jpg" 'Load the file
    Picture1.Picture = .GetPicture 'Display in the picture control
    labW.Caption = .Width 'On indique sa largeur
    labH.Caption = .Height 'sa hauteur
End With
End Sub

Private Sub Form_Unload(Cancel As Integer)
Set Ctrl = Nothing 'Remove object isntance
End Sub

Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
cx = ScaleX(X, vbTwips, vbPixels) 'Convert data from Twips in Pixels
cy = ScaleY(Y, vbTwips, vbPixels)

labX.Caption = cx  'Display values
labY.Caption = cy

labPick.BackColor = Ctrl.GetColorAt(cx, cy) 'Display color of a pixel
End Sub
