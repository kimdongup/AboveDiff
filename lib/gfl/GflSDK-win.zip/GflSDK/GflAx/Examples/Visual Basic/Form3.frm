VERSION 5.00
Begin VB.Form Form3 
   Caption         =   "Form3"
   ClientHeight    =   5100
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   6675
   LinkTopic       =   "Form3"
   ScaleHeight     =   5100
   ScaleWidth      =   6675
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
Dim Ctrl As GflAx.GflAx
Set Ctrl = New GflAx.GflAx

Dim newWidth As Long
Dim newHeight As Long

With Ctrl
    .LoadBitmap App.Path & "\image.jpg" 'Load the file
    
    newWidth = 250 'Get height according to the width (keep ratio)
    newHeight = (newWidth * .Height) / .Width
    
    .Resize newWidth, newHeight 'Resize picture
    
    .FontName = "arial"
    .FontSize = 13
    .TextOut .About, 2, 2, RGB(255, 255, 255) 'Write library version on the picture
    
    Me.Picture = .GetPicture 'Display picture
End With

Set Ctrl = Nothing
End Sub

