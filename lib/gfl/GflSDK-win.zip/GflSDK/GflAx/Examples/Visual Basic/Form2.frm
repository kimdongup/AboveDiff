VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Form2"
   ClientHeight    =   4125
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   5520
   LinkTopic       =   "Form2"
   ScaleHeight     =   4125
   ScaleWidth      =   5520
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
Dim Ctrl As GflAx.GflAx
Set Ctrl = New GflAx.GflAx

With Ctrl
    .LoadBitmap App.Path & "\image.jpg" 'Load the file
    .ChangeColorDepth AX_To16Colors 'Change color depth
    .FlipHorizontal 'Horizontal flip
    .ResizeCanvas .Width + 10, .Height + 10, RGB(255, 255, 255) 'Enlarge size of 10 pixels..
    Me.Picture = .GetPicture 'Display picture
End With

Set Ctrl = Nothing
End Sub
