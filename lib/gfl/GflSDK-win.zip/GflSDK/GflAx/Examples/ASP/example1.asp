<%
'   Load a picture, and display informations.

Dim Path, File

Set ctrl = server.createobject("GflAx.GflAx")
Path = Server.MapPath("/GflAx") 
File = Path & "\image.jpg"

With ctrl
	.LoadBitmap File
%>
	<table border="1">
		<tr><td width="150"><b>Width</b></td>		<td width="100"><% =response.write(.Width) %> px</td>
			<td rowspan="8" valign="top"><img src="image.asp?<% =file %>"></td>
		</tr>	
		<tr><td><b>Height</b></td>					<td><% =response.write(.height) %> px</td></tr>	
		<tr><td><b>ColorModel</b></td>				<td><% =response.write(.ColorModel) %></td></tr>	
		<tr><td><b>BitmapType</b></td>				<td><% =response.write(BitmapTypeLabel(.BitmapType)) %></td></tr>	
		<tr><td><b>Xdpi</b></td>					<td><% =response.write(.Xdpi) %> dpi</td></tr>	
		<tr><td><b>Ydpi</b></td>					<td><% =response.write(.Ydpi) %> dpi</td></tr>	
		<tr><td><b>NumberOfImage</b></td>			<td><% =response.write(.NumberOfImages) %> image(s)</td></tr>	
		<tr><td><b>OriginalSize</b></td>			<td><% =response.write(.OriginalSize) %> ko</td></tr>	
	</table>
<%
end with

set ctrl=nothing

Function BitmapTypeLabel(BitmapType)
	select case BitmapType
		case 1: BitmapTypeLabel="Binary"
		case 2: BitmapTypeLabel="Grey"
		case 3: BitmapTypeLabel="Colors"
		case 4: BitmapTypeLabel="True Colors"
	end select
End function

%>
