<%
'   Load a picture, change the color depth. Horizontal flip
'   resize his canevas, and display it.

'   Use a ASP file as source of a <IMG> tag to display a picture in a HTML page

'   The following contenttype are available :
'   response.contenttype = "image/jpeg"
'   response.contenttype = "image/gif"
'	response.contenttype = "image/png"
'	response.contenttype = "image/bmp"
'	response.contenttype = "image/tiff"
'	response.contenttype = "image/xpm"

Dim Path, File

Set ctrl = server.createobject("GflAx.GflAx")
Path = Server.MapPath("/GflAx") 
File = Path & "\image.jpg"

With ctrl
	.EnableLZW = TRUE
	.MergeAddFile Path & "\img0.tif", 40, 0, 0
	.MergeAddFile Path & "\img1.tif", 15, 0, 0
	.MergeAddFile Path & "\img2.tif", 15, 0, 0
	.MergeAddFile Path & "\img3.tif", 20, 0, 0
	.Merge

	.SaveformatName = "jpeg"
	response.contenttype = "image/jpeg"
	response.binarywrite .SendBinary
end with

set ctrl=nothing
%>
