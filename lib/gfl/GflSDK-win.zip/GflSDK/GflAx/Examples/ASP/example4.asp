<%
'   Charge une image, modifie son orientation de 90�, l'enregistre au format JPEG
'   et l'affiche dans la page.

'   Use a ASP file as source of a <IMG> tag to display a picture in a HTML page

'   The following contenttype are available :
'   response.contenttype = "image/jpeg"
'   response.contenttype = "image/gif"
'	response.contenttype = "image/png"
'	response.contenttype = "image/bmp"
'	response.contenttype = "image/tiff"
'	response.contenttype = "image/xpm"

Dim Path, File

Set ctrl = server.createobject("GflAx.GflAx")
Path = Server.MapPath("/GflAx") 
File = Path & "\image.jpg"

With ctrl
	.LoadBitmap File
	.Rotate 90 'Rotation of 90�
	.SaveJPEGProgressive = True 'Progressive
	.SaveJPEGQuality = 70 'Quality of 70%
	.SaveBitmap Path & "\result.jpg"
    
	.SaveformatName = "jpeg"
	response.contenttype = "image/jpeg"
	response.binarywrite .SendBinary
end with

set ctrl=nothing
%>
