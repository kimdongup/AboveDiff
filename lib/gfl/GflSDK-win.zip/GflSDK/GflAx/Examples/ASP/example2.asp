<%
'   Load a picture, change the color depth. Horizontal flip
'   resize his canevas, and display it.

'   Use a ASP file as source of a <IMG> tag to display a picture in a HTML page

'   The following contenttype are available :
'   response.contenttype = "image/jpeg"
'   response.contenttype = "image/gif"
'	response.contenttype = "image/png"
'	response.contenttype = "image/bmp"
'	response.contenttype = "image/tiff"
'	response.contenttype = "image/xpm"

Dim Path, File

Set ctrl = server.createobject("GflAx.GflAx")
Path = Server.MapPath("/GflAx") 
File = Path & "\image.jpg"

const AX_To16Colors = 16

With ctrl
	.LoadBitmap File
	.ChangeColorDepth AX_To16Colors
	.FlipHorizontal
	.ResizeCanvas .Width +10, .Height +10, RGB(0,0,0)
	.SaveformatName = "jpeg"

	response.contenttype = "image/jpeg"
	response.binarywrite .SendBinary
end with

set ctrl=nothing
%>
