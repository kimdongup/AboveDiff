<%
'   Load a picture, change the color depth. Enlarge the picture according his width (ratio),
'   add a text, and display it.

'   Use a ASP file as source of a <IMG> tag to display a picture in a HTML page

'   The following contenttype are available :
'   response.contenttype = "image/jpeg"
'   response.contenttype = "image/gif"
'	response.contenttype = "image/png"
'	response.contenttype = "image/bmp"
'	response.contenttype = "image/tiff"
'	response.contenttype = "image/xpm"

Dim Path, File

Set ctrl = server.createobject("GflAx193.GflAx")
Path = Server.MapPath("/GflAx") 
File = Path & "\image.jpg"

const AX_JPEG = 3
const AX_To16Colors = 16

With ctrl
	.LoadBitmap File
    .ChangeColorDepth AX_To16Colors

    newWidth = 250 'Get the height according to the width (keep the ratio)
    newHeight = (newWidth * .Height) / .Width
    
    .Resize newWidth, newHeight 'Resize the pciture
    
    .FontName = "arial"
    .FontSize = 13
    .TextOut .About, 2, 2, RGB(255, 255, 255) 'Write library version on the picture
    
    .Saveformat = AX_JPEG

	response.contenttype = "image/jpeg"
	response.binarywrite .SendBinary
end with

set ctrl=nothing
%>
