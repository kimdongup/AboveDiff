<%
	' Documented by : Bryce Christensen (bryce@esonica.com)
	' Revision 1. 16 January, 2007 
	' Page for sending the binary information for a requested file.
	' Usage : In HTML, use the following format for calling an image using the resize

	' <img src="sendBinary.asp?img=test.JPG&h=100&w=100">
	
	' with w and h parameters are optional, you can enter one, both, or none.
	' the img parameter is required in the querystring
	
	
	Dim rqFile
	rqFile = "" & Request.QueryString("img") & ""
	
	IF rqFile = "" OR InStr(1, rqFile, "\") > 0 OR InStr(1, rqFile, ".") < Len(rqFile) - 4 THEN
		' looks like someones trying to sploit this
	ELSE

		Dim MyObj
		Set MyObj = Server.CreateObject("GflAx.GflAx") 
	
		Dim rqWidth, rqHeight
		rqWidth = "" & Request.QueryString("w") & ""
		rqHeight = "" & Request.QueryString("h") & ""

		' check if a resized image has been requested
		IF rqWidth <> "" OR rqHeight <> "" THEN

			MyObj.LoadBitmap(Server.MapPath(".") & "/" & rqFile & "")
			
			Dim orHeight, orWidth
			orHeight = MyObj.height
			orWidth = MyObj.width
			
			IF rqWidth = "" THEN
				rqWidth = orWidth * rqHeight / orHeight
			END IF
			
			IF rqHeight = "" THEN
				rqHeight = orHeight * rqWidth / orWidth
			END IF
			
			MyObj.Resize rqWidth, rqHeight
			Response.BinaryWrite MyObj.SendBinary()
			
		ELSE
		
			MyObj.LoadBitmap(Server.MapPath(".") & "/" & rqFile & "")
			Response.BinaryWrite MyObj.SendBinary()
		
		END IF
		
		Set MyObj = Nothing 
		
	END IF
%>
