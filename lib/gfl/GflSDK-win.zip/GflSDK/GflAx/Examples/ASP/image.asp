<%
'   Use a ASP file as source of a <IMG> tag to display a picture in a HTML page
'   add a text.

'   The following contenttype are available :
'   response.contenttype = "image/jpeg"
'   response.contenttype = "image/gif"
'	response.contenttype = "image/png"
'	response.contenttype = "image/bmp"
'	response.contenttype = "image/tiff"
'	response.contenttype = "image/xpm"

Dim Path, File

Set ctrl = server.createobject("GflAx.GflAx")
File = request.querystring

With ctrl
	.enablelzw= True
	.LoadBitmap file
	.SaveformatName = "jpeg"

	.FontName = "arial"
	.FontSize = 13
	.TextOut "GflAx 200 - Exemple 1", 5, 5, RGB(255, 255, 255) 'Write library version on the picture

	response.contenttype = "image/jpeg"
	response.binarywrite .SendBinary
end with

set ctrl=nothing
%>
