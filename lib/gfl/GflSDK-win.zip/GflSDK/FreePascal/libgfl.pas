{
  Graphics File Library
  For Windows & Unix

  GFL library Copyright (c) 1991-2005 Pierre-e Gougelet
  All rights reserved

  Commercial use is not authorized without agreement

  URL:     http://www.xnview.com
  E-Mail : webmaster@xnview.com

  Version 2.54

  ------------------------------------------------------------------------------
  Translation of libgfl.h as import unit for Free Pascal by

  Guus Scholten
  E-Mail : jacco@wishmail.net

  Free Pascal version used : 1.0.6 under Windows ME


  ------------------------------------------------------------------------------
  History:
  DD/MM/YYYY
  03/12/2003: by Guus Scholten (jacco@wishmail.net)
              update from version 1.93 to 2.01

  DD/MM/YYYY
  05/07/2003: by Guus Scholten (jacco@wishmail.net)
              update from version 1.90 to 1.93

  DD/MM/YYYY
  30/04/2003: by Guus Scholten (jacco@wishmail.net)
              + initial creation (version 1.90)
}

{$macro on}
{$define GFLDLL:= external 'libgfl254.dll'}
{$define GFLEDLL:= external 'libgfle254.dll'}

unit LibGFL;

interface

uses windows;
  {
    Allignment of records : 8 byte allignment required
  }

const
   PlugIns     = 'C:\Program Files\XnView\PlugIns\';

   GFL_VERSION = '2.54';

   GFL_FALSE   = 0;
   GFL_TRUE    = 1;

type
   GFL_INT8   = ShortInt;
   GFL_UINT8  = Byte;
   GFL_INT16  = SmallInt;
   GFL_UINT16 = Word;
   GFL_INT32  = LongInt;
   GFL_UINT32 = DWord;
   GFL_BOOL   = Byte;

   PGFL_UINT8  = ^GFL_UINT8;
   PGFL_UINT16 = ^GFL_UINT16;
   PGFL_UINT32 = ^GFL_UINT32;

{ ERROR messages }
type
   GFL_ERROR                    = GFL_INT16;

const
   GFL_NO_ERROR                 =   0;
   GFL_ERROR_FILE_OPEN          =   1;
   GFL_ERROR_FILE_READ          =   2;
   GFL_ERROR_FILE_CREATE        =   3;
   GFL_ERROR_FILE_WRITE         =   4;
   GFL_ERROR_NO_MEMORY          =   5;
   GFL_ERROR_UNKNOWN_FORMAT     =   6;
   GFL_ERROR_BAD_BITMAP         =   7;
   GFL_ERROR_BAD_FORMAT_INDEX   =  10;
   GFL_ERROR_BAD_PARAMETERS     =  50;
   GFL_UNKNOWN_ERROR            = 255;

{ ORIGIN type }
type
   GFL_ORIGIN                   = GFL_UINT16;

const
   GFL_LEFT                     = $00;
   GFL_RIGHT                    = $01;
   GFL_TOP                      = $00;
   GFL_BOTTOM                   = $10;
   GFL_TOP_LEFT                 = GFL_TOP or GFL_LEFT;
   GFL_BOTTOM_LEFT              = GFL_BOTTOM or GFL_LEFT;
   GFL_TOP_RIGHT                = GFL_TOP or GFL_RIGHT;
   GFL_BOTTOM_RIGHT             = GFL_BOTTOM or GFL_RIGHT;

{ COMPRESSION type }
type
   GFL_COMPRESSION              = GFL_UINT16;

const
   GFL_NO_COMPRESSION           =   0;
   GFL_RLE                      =   1;
   GFL_LZW                      =   2;
   GFL_JPEG                     =   3;
   GFL_ZIP                      =   4;
   GFL_SGI_RLE                  =   5;
   GFL_CCITT_RLE                =   6;
   GFL_CCITT_FAX3               =   7;
   GFL_CCITT_FAX3_2D            =   8;
   GFL_CCITT_FAX4               =   9;
   GFL_WAVELET                  =  10;
   GFL_LZW_PREDICTOR            =  11;
   GFL_UNKNOWN_COMPRESSION      = 255;

{ BITMAP type }
type
   GFL_BITMAP_TYPE              = GFL_UINT16;

const
   GFL_BINARY                   = $0001;
   GFL_GREY                     = $0002;
   GFL_COLORS                   = $0004;
   GFL_RGB                      = $0010;
   GFL_RGBA                     = $0020;
   GFL_BGR                      = $0040;
   GFL_ABGR                     = $0080;
   GFL_BGRA                     = $0100;
   GFL_ARGB                     = $0200;
   GFL_CMYK                     = $0400;

{ Obsolete, no longer used in this way }
//   GFL_24BITS                   = GFL_RGB or GFL_BGR;
//   GFL_32BITS                   = GFL_RGBA or GFL_ABGR or GFL_BGRA or GFL_ARGB or GFL_CMYK;
//   GFL_TRUECOLORS               = GFL_24BITS or GFL_32BITS;
//  function gfl_Is24Bits     ( _a : GFL_BITMAP_TYPE ) : Boolean;
//  function gfl_Is32Bits     ( _a : GFL_BITMAP_TYPE ) : Boolean;

   GFL_24BITS                   = $1000; { Only for gflBitmapTypeIsSupportedByIndex or gflBitmapTypeIsSupportedByName }
   GFL_32BITS                   = $2000;
   GFL_48BITS                   = $4000;
   GFL_64BITS                   = $8000;

{ This function was a macro }
function gfl_IsTrueColors ( _a : GFL_BITMAP_TYPE ) : Boolean;

{ Color Palette }
type
  GFL_COLORMAP  = record
                     Red   : array[0..255] of GFL_UINT8;
                     Green : array[0..255] of GFL_UINT8;
                     Blue  : array[0..255] of GFL_UINT8;
                   end;
   PGFL_COLORMAP = ^GFL_COLORMAP;

{ Color structure }
type
   GFL_COLOR  = record
                  Red   : GFL_UINT8;
                  Green : GFL_UINT8;
                  Blue  : GFL_UINT8;
                  Alpha : GFL_UINT8;
                end;
   PGFL_COLOR = ^GFL_COLOR;

{ BITMAP structure }
type
   GFL_BITMAP   = record
                    TType            : GFL_BITMAP_TYPE; // Type is a Pascal reseved word, used TType instead!
                    Origin           : GFL_ORIGIN;
                    Width            : GFL_INT32;
                    Height           : GFL_INT32;
                    BytesPerLine     : GFL_UINT32;
                    LinePadding      : GFL_INT16;
                    Reserved         : GFL_INT16;
                    BytesPerPixel    : GFL_UINT8;
                    BitsPerComponent : GFL_UINT8;       // Always 8
                    Xdpi             : GFL_UINT16;
                    Ydpi             : GFL_UINT16;
                    TransparentIndex : GFL_INT16;       // -1 if not used
                    Reserved         : GFL_INT16; 
                    ColorUsed        : GFL_INT32;
                    ColorMap         : PGFL_COLORMAP;
                    Data             : PGFL_UINT8;
                    Comment          : PCHAR;
                    MetaData         : Pointer;
                  end;
   PGFL_BITMAP  = ^GFL_BITMAP;
   PPGFL_BITMAP = ^PGFL_BITMAP;

{ Channels Order }
type
   GFL_CORDER             = GFL_UINT16;

const
   GFL_CORDER_INTERLEAVED = 0;
   GFL_CORDER_SEQUENTIAL  = 1;
   GFL_CORDER_SEPARATE    = 2;

{ Channels Type }
type
   GFL_CTYPE           = GFL_UINT16;

const
   GFL_CTYPE_GREYSCALE = 0;
   GFL_CTYPE_RGB       = 1;
   GFL_CTYPE_BGR       = 2;
   GFL_CTYPE_RGBA      = 3;
   GFL_CTYPE_ABGR      = 4;
   GFL_CTYPE_CMY       = 5;
   GFL_CTYPE_CMYK      = 6;

{ Lut Type (For DPX/Cineon) }
type
   GFL_LUT_TYPE        = GFL_UINT16;
   PGFL_LUT_TYPE       = ^GFL_LUT_TYPE;

const
   GFL_LUT_TO8BITS     =  1;
   GFL_LUT_TO10BITS    =  2;
   GFL_LUT_TO12BITS    =  3;
   GFL_LUT_TO16BITS    =  4 ;

{ Callbacks }
type
   GFL_HANDLE = Pointer;

   GFL_ALLOC_CALLBACK   = procedure( size    : GFL_UINT32;
                                     param   : Pointer     );              stdcall;
   GFL_REALLOC_CALLBACK = procedure( ptr     : Pointer;
                                     newsize : GFL_UINT32;
                                     param   : Pointer     );              stdcall;
   GFL_FREE_CALLBACK    = procedure( buffer  : Pointer;
                                     param   : Pointer     );              stdcall;

   GFL_READ_CALLBACK    = function ( handle  : GFL_HANDLE;
                                     buffer  : Pointer;
                                     size    : GFL_UINT32  ) : GFL_UINT32; stdcall;
   GFL_TELL_CALLBACK    = function ( handle  : GFL_HANDLE  ) : GFL_UINT32; stdcall;
   GFL_SEEK_CALLBACK    = function ( handle  : GFL_HANDLE;
                                     offset  : GFL_INT32;
                                     origin  : GFL_INT32   ) : GFL_UINT32; stdcall;
   GFL_WRITE_CALLBACK   = function ( handle  : GFL_HANDLE;
                                     buffer  : Pointer;
                                     size    : GFL_UINT32  ) : GFL_UINT32; stdcall;

   GFL_ALLOCATEBITMAP_CALLBACK = function ( width  : GFL_INT32;
                                     height  : GFL_INT32;
                                     number_component  : GFL_INT32;
                                     bits_per_component  : GFL_INT32;
                                     padding  : GFL_INT32;
                                     bytes_per_line  : GFL_INT32;
                                     user_params  : Pointer  ) : Pointer; stdcall;
   GFL_PROGRESS_CALLBACK       = procedure ( percent  : GFL_INT32;
                                     user_params  : Pointer  ); stdcall;
   GFL_WANTCANCEL_CALLBACK     = function ( user_params  : Pointer ) : GFL_BOOL; stdcall;

type
   GFL_LOAD_CALLBACKS  = record
                           Read       : GFL_READ_CALLBACK;
                           Tell       : GFL_TELL_CALLBACK;
                           Seek       : GFL_SEEK_CALLBACK;

                           AllocateBitmap : GFL_ALLOCATEBITMAP_CALLBACK; 
                           AllocateBitmapParams : Pointer; 
                           Progress : GFL_PROGRESS_CALLBACK; 
                           ProgressParams : Pointer; 
                           WantCancel : GFL_WANTCANCEL_CALLBACK; 
                           WantCancelParams : Pointer; 
                         end;
   PGFL_LOAD_CALLBACKS = ^GFL_LOAD_CALLBACKS;

type
   GFL_SAVE_CALLBACKS  = record
                           Write      : GFL_WRITE_CALLBACK;
                           Tell       : GFL_TELL_CALLBACK;
                           Seek       : GFL_SEEK_CALLBACK;
                         end;
   PGFL_SAVE_CALLBACKS = ^GFL_SAVE_CALLBACKS;

{ LOAD_PARAMS Flags }
const
   GFL_LOAD_SKIP_ALPHA               = $0001;  // If the bitmap is 32 bits, then alpha is not loaded
   GFL_LOAD_IGNORE_READ_ERROR        = $0002;
   GFL_LOAD_BY_EXTENSION_ONLY        = $0004;  // Use only extension to recognize format. Faster
   GFL_LOAD_READ_ALL_COMMENT         = $0008;  // Read Comment in GFL_FILE_DESCRIPTION
   GFL_LOAD_FORCE_COLOR_MODEL        = $0010;  // Force to load picture in the ColorModel
   GFL_LOAD_PREVIEW_NO_CANVAS_RESIZE = $0020;  // With gflLoadPreview, width & height are the maximum box
   GFL_LOAD_BINARY_AS_GREY           = $0040;  // Load Black&White file in greyscale
   GFL_LOAD_ORIGINAL_COLORMODEL      = $0080;  // If the colormodel is CMYK, keep it
   GFL_LOAD_ONLY_FIRST_FRAME         = $0100;  // No search to check if file is multi-frame
   GFL_LOAD_ORIGINAL_DEPTH           = $0200;  // In the case of 10/16 bits per component
   GFL_LOAD_METADATA                 = $0400;  // Read all metadata
   GFL_LOAD_COMMENT                  = $0800;  // Read comment
   GFL_LOAD_HIGH_QUALITY_THUMBNAIL   = $1000;  // gflLoadThumbnail

{ LOAD_PARAMS structure }
type
   GFL_LOAD_PARAMS  = record
                        Flags        : GFL_UINT32;
                        FormatIndex  : GFL_INT32;       // -1 for automatic recognition
                        ImageWanted  : GFL_INT32;       // for multi-page or animated file
                        Origin       : GFL_ORIGIN;      // default: GFL_TOP_LEFT
                        ColorModel   : GFL_BITMAP_TYPE; // Only for 24/32 bits picture, GFL_RGB/GFL_RGBA (default), GFL_BGR/GFL_ABGR, GFL_BGRA, GFL_ARGB
                        LinePadding  : GFL_UINT32;      // 1 (default), 2, 4, ....
                        DefaultAlpha : GFL_UINT8;       // Used if alpha doesn't exist in original file & ColorModel=RGBA/BGRA/ABGR/ARGB
                        Reserved1    : GFL_UINT8;
                        Reserved2    : GFL_UINT16;
                        // for RAW/YUV only
                        Width        : GFL_INT32;
                        Height       : GFL_INT32;
                        Offset       : GFL_UINT32;
                        // for RAW only
                        ChannelOrder : GFL_CORDER;
                        ChannelType  : GFL_CTYPE;
                         // for PCD only
                        PcdBase      : GFL_UINT16;      // PCD -> 2:768x576, 1:384x288, 0:192x144
                        // EPS/PS/AI/PDF only
                        EpsDpi       : GFL_UINT16;
                        EpsWidth     : GFL_INT32;
                        EpsHeight    : GFL_INT32;
                        // For Dpx, Cineon
                        LutType      : GFL_LUT_TYPE;    // GFL_LUT_TO8BITS, GFL_LUT_TO8BITS, GFL_LUT_TO8BITS
	                    Reserved3    : GFL_UINT16;
                        LutData      : PGFL_UINT16; // RRRR.../GGGG..../BBBB.....
                        LutFilename  : PChar;
                        // Own callback
                        Callbacks    : GFL_LOAD_CALLBACKS;
                      end;
   PGFL_LOAD_PARAMS = ^GFL_LOAD_PARAMS;

// support of GFL_BITMAP ChannelTypes: GFL_RGB + GFL_RGBA + GFL_BGR
// support of GFL_BITMAP OriginTypes: GFL_TOP_LEFT + GFL_BOTTOM_LEFT

{ SAVE_PARAMS flags }
const
   GFL_SAVE_REPLACE_EXTENSION = $0001;
   GFL_SAVE_WANT_FILENAME     = $0002;
   GFL_SAVE_ANYWAY            = $0004;

type
   GFL_SAVE_PARAMS  = record
                        Flags                : GFL_UINT32;
                        FormatIndex          : GFL_INT32;
                        Compression          : GFL_COMPRESSION;
                        Quality              : GFL_INT16;         // Jpeg + Wic + Fpx
                        CompressionLevel     : GFL_INT16;         // Png
                        Interlaced           : GFL_BOOL;          // Gif
                        Progressive          : GFL_BOOL;          // Jpeg
		                OptimizeHuffmanTable : GFL_BOOL;          // Jpeg
		                InAscii              : GFL_BOOL;          // PPM
                        // For Dpx, Cineon
                        LutType              : GFL_LUT_TYPE;      // GFL_LUT_TO8BITS, GFL_LUT_TO8BITS, GFL_LUT_TO8BITS
	                    Reserved3            : GFL_UINT16;
                        LutData              : PGFL_UINT16;       // RRRR.../GGGG..../BBBB.....
                        LutFilename: PChar;
                        // For RAW/YUV
                        Offset               : GFL_UINT32;
                        ChannelOrder         : GFL_CORDER;
                        ChannelType          : GFL_CTYPE;
                        // Own callback
                        Callbacks            : GFL_SAVE_CALLBACKS;
                      end;
   PGFL_SAVE_PARAMS = ^GFL_SAVE_PARAMS;

{ Color model }
type
   GFL_COLORMODEL = GFL_UINT16;

const
   GFL_CM_RGB    = 0;
   GFL_CM_GREY   = 1;
   GFL_CM_CMY    = 2;
   GFL_CM_CMYK   = 3;
   GFL_CM_YCBCR  = 4;
   GFL_CM_YUV16  = 5;
   GFL_CM_LAB    = 6;
   GFL_CM_LOGLUV = 7;
   GFL_CM_LOGL   = 8;

{ FILE_INFORMATION structure }
type
   GFL_FILE_INFORMATION  = record
                             TType                  : GFL_BITMAP_TYPE;
                             Origin                 : GFL_ORIGIN;
                             Width                  : GFL_INT32;
                             Height                 : GFL_INT32;
                             FormatIndex            : GFL_INT32;
                             FormatName             : array[0..7] of char;
                             Description            : array[0..63] of char;
                             Xdpi                   : GFL_UINT16;
                             Ydpi                   : GFL_UINT16;
                             BitsPerPlane           : GFL_UINT16;
                             NumberOfPlanes         : GFL_UINT16;
                             BytesPerPlane          : GFL_UINT32;
                             NumberOfImages         : GFL_INT32;
                             FileSize               : GFL_UINT32;
                             ColorModel             : GFL_COLORMODEL;
                             Compression            : GFL_COMPRESSION;
                             CompressionDescription : array[0..63] of char;
                             XOffset                : GFL_INT32;
                             YOffset                : GFL_INT32;
                           end;
   PGFL_FILE_INFORMATION = ^GFL_FILE_INFORMATION;

const
   GFL_READ	 = $01;
   GFL_WRITE = $02;

{ FORMAT_INFORMATION structure }
type
   GFL_FORMAT_INFORMATION  = record
                               Index             : GFL_INT32;
                               Name              : array[0..7] of char;
                               Description       : array[0..63] of char;
                               Status            : GFL_UINT32;
                               NumberOfExtension : GFL_UINT32;
                               Extension         : array[0..15, 0..7] of char;
                             end;
   PGFL_FORMAT_INFORMATION = ^GFL_FORMAT_INFORMATION;

{ IPTC }
type
   GFL_IPTC_ENTRY  = record
                       Id    : GFL_UINT32;
                       Name  : PCHAR;
                       Value : PCHAR;
                     end;
   PGFL_IPTC_ENTRY = ^GFL_IPTC_ENTRY;

type
   GFL_IPTC_DATA  = record
                      NumberOfItems : GFL_UINT32;
                      ItemsList     : PGFL_IPTC_ENTRY;
                    end;
   PGFL_IPTC_DATA = ^GFL_IPTC_DATA;

{ EXIF }
const
   EXIF_MAIN_IFD             = $0001;
   EXIF_IFD_0                = $0002;
   EXIF_INTEROPERABILITY_IFD = $0004;
   EXIF_IFD_THUMBNAIL        = $0008;
   EXIF_GPS_IFD              = $0010;
   EXIF_MAKERNOTE_IFD        = $0020;

type
   GFL_EXIF_ENTRY  = record
                       Flag  : GFL_UINT32; // EXIF_...IFD
                       Tag   : GFL_UINT32;
                       Name  : PCHAR;
                       Value : PCHAR;
                     end;
   PGFL_EXIF_ENTRY = ^GFL_EXIF_ENTRY;

type
   GFL_EXIF_DATA  = record
                      NumberOfItems : GFL_UINT32;
                      ItemsList     : PGFL_EXIF_ENTRY;
                    end;
   PGFL_EXIF_DATA = ^GFL_EXIF_DATA;

{
  ---------------------------------------------------------------------------------------------------
  functions in LibGflxxx.dll
  ---------------------------------------------------------------------------------------------------
}

{ Common Memory Handling }

function  gflMemoryAlloc   ( size : GFL_UINT32 ) : PVOID;      GFLDLL;
function  gflMemoryRealloc ( Ptr  : PVOID;
                             size : GFL_UINT32 ) : PVOID;      GFLDLL;
procedure gflMemoryFree    ( Ptr  : PVOID      );              GFLDLL;

{ Version Info }
function  gflGetVersion                          : PChar;      GFLDLL;
function  gflGetVersionOfLibformat               : PChar;      GFLDLL;

{ Initialization }
function  gflLibraryInit                                                     : GFL_ERROR;  GFLDLL;
function  gflLibraryInitEx      ( alloc_callback   : GFL_ALLOC_CALLBACK;
                                  realloc_callback : GFL_REALLOC_CALLBACK;
                                  free_callback    : GFL_FREE_CALLBACK;
                                  user_parms       : pointer               ) : GFL_ERROR;  GFLDLL;
procedure gflLibraryExit;                                                                  GFLDLL;
procedure gflEnableLZW          ( value            : GFL_BOOL              );              GFLDLL; // If you have the Unisys license
procedure gflSetPluginsPathname ( pathname         : PChar                 );              GFLDLL;

{ Info's of supported Formats }
function  gflGetNumberOfFormat                                                : GFL_INT32;   GFLDLL;
function  gflGetFormatIndexByName         ( name  : PChar                   ) : GFL_INT32;   GFLDLL;
function  gflGetFormatNameByIndex         ( index : GFL_INT32               ) : PChar;       GFLDLL;
function  gflFormatIsSupported            ( name  : PChar                   ) : GFL_BOOL;    GFLDLL;
function  gflFormatIsWritableByIndex      ( index : GFL_INT32               ) : GFL_BOOL;    GFLDLL;
function  gflFormatIsWritableByName       ( name  : PChar                   ) : GFL_BOOL;    GFLDLL;
function  gflFormatIsReadableByIndex      ( index : GFL_INT32               ) : GFL_BOOL;    GFLDLL;
function  gflFormatIsReadableByName       ( name  : PChar                   ) : GFL_BOOL;    GFLDLL;
function  gflGetDefaultFormatSuffixByIndex( index : GFL_INT32               ) : PChar;       GFLDLL;
function  gflGetDefaultFormatSuffixByName ( name  : PChar                   ) : PChar;       GFLDLL;
function  gflGetFormatDescriptionByIndex  ( index : GFL_INT32               ) : PChar;       GFLDLL;
function  gflGetFormatDescriptionByName   ( name  : PChar                   ) : PChar;       GFLDLL;
function  gflGetFormatInformationByIndex  ( index : GFL_INT32;
                                            info  : PGFL_FORMAT_INFORMATION ) : GFL_ERROR;   GFLDLL;
function  gflGetFormatInformationByName   ( name  : PChar;
                                            info  : PGFL_FORMAT_INFORMATION ) : GFL_ERROR;   GFLDLL;

type
   GFL_SAVE_PARAMS_TYPE = GFL_UINT32;

const
   GFL_SAVE_PARAMS_QUALITY           = 0;  // 0<=quality<=100
   GFL_SAVE_PARAMS_COMPRESSION_LEVEL = 1;  // 0<=level<=9
   GFL_SAVE_PARAMS_INTERLACED        = 2;
   GFL_SAVE_PARAMS_PROGRESSIVE       = 3;
   GFL_SAVE_PARAMS_OPTIMIZE_HUFFMAN  = 4;
   GFL_SAVE_PARAMS_IN_ASCII          = 5;
   GFL_SAVE_PARAMS_LUT               = 6;

function gflSaveParamsIsSupportedByIndex ( index : GFL_INT32;
                                           ttype : GFL_SAVE_PARAMS_TYPE ) : GFL_BOOL; GFLDLL;
function gflSaveParamsIsSupportedByName  ( name  : PCHAR;
                                           ttype : GFL_SAVE_PARAMS_TYPE ) : GFL_BOOL; GFLDLL;
function gflCompressionIsSupportedByIndex( index : GFL_INT32;
                                           comp  : GFL_COMPRESSION      ) : GFL_BOOL; GFLDLL;
function gflCompressionIsSupportedByName ( name  : PCHAR;
                                           comp  : GFL_COMPRESSION      ) : GFL_BOOL; GFLDLL;
function gflBitmapIsSupportedByIndex     ( index : GFL_INT32;
                                           pbmp  : PGFL_BITMAP          ) : GFL_BOOL; GFLDLL;
function gflBitmapIsSupportedByName      ( name  : PCHAR;
                                           pbmp  : PGFL_BITMAP          ) : GFL_BOOL; GFLDLL;
function gflBitmapTypeIsSupportedByIndex ( index              : GFL_INT32;
                                           ttype              : GFL_BITMAP_TYPE;
                                           bits_per_component : GFL_UINT16      ) : GFL_BOOL; GFLDLL;
function gflBitmapTypeIsSupportedByName  ( name               : PCHAR;
                                           ttype              : GFL_BITMAP_TYPE;
                                           bits_per_component : GFL_UINT16      ) : GFL_BOOL; GFLDLL;

{ Other Info's }
function  gflGetErrorString               ( error       : GFL_ERROR             ) : PChar;       GFLDLL;
function  gflGetLabelForColorModel        ( color_model : GFL_COLORMODEL        ) : PChar;       GFLDLL;
function  gflGetFileInformation           ( filename    : PChar;
                                            index       : GFL_INT32;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;   GFLDLL;
function  gflGetFileInformationFromHandle ( hGFL        : GFL_HANDLE;
                                            index       : GFL_INT32;
                                            callbacks   : PGFL_LOAD_CALLBACKS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;   GFLDLL;
procedure gflFreeFileInformation          ( info        : PGFL_FILE_INFORMATION );               GFLDLL;

{ Loading and Saving }
procedure gflGetDefaultLoadParams         ( params      : PGFL_LOAD_PARAMS      );               GFLDLL;
function  gflLoadBitmap                   ( filename    : PChar;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;   GFLDLL;
function  gflLoadBitmapFromHandle         ( hGFL        : GFL_HANDLE;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;   GFLDLL;

procedure gflGetDefaultThumbnailParams    ( params      : PGFL_LOAD_PARAMS      );               GFLDLL;
function  gflLoadThumbnail                ( filename    : PChar;
                                            width       : GFL_INT32;
                                            height      : GFL_INT32;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;   GFLDLL;
function  gflLoadThumbnailFromHandle      ( hGFL        : GFL_HANDLE;
                                            width       : GFL_INT32;
                                            height      : GFL_INT32;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;   GFLDLL;

procedure gflGetDefaultPreviewParams      ( params      : PGFL_LOAD_PARAMS      );
function  gflLoadPreview                  ( filename    : PChar;
                                            width       : GFL_INT32;
                                            height      : GFL_INT32;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;
function  gflLoadPreviewFromHandle        ( hGFL        : GFL_HANDLE;
                                            width       : GFL_INT32;
                                            height      : GFL_INT32;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;

procedure gflGetDefaultSaveParams         ( params      : PGFL_SAVE_PARAMS      );               GFLDLL;
function  gflSaveBitmap                   ( filename    : PChar;
                                            bmp         : PGFL_BITMAP;
                                            params      : PGFL_SAVE_PARAMS      ) : GFL_ERROR;   GFLDLL;
function  gflSaveBitmapIntoHandle         ( hGFL        : GFL_HANDLE;
                                            bmp         : PGFL_BITMAP;
                                            params      : PGFL_SAVE_PARAMS      ) : GFL_ERROR;   GFLDLL;

{ Multi-page file }
type
   GFL_FILE_HANDLE  = Pointer;

function  gflFileCreate     ( var hGFL    : GFL_FILE_HANDLE;
                              filename    : PChar;
                              image_count : GFL_UINT32;
                              params      : PGFL_SAVE_PARAMS ) : GFL_ERROR;   GFLDLL;
function  gflFileAddPicture ( hGFL        : GFL_FILE_HANDLE;
                              bmp         : PGFL_BITMAP      ) : GFL_ERROR;   GFLDLL;
procedure gflFileClose      ( hGFL        : GFL_FILE_HANDLE  );               GFLDLL;


{ Bitmap Memory Handling }
function  gflAllockBitmap   ( TType              : GFL_BITMAP_TYPE;
                              width              : GFL_INT32;
                              height             : GFL_INT32;
                              line_padding       : GFL_UINT32;
                              color              : PGFL_COLOR      ) : PGFL_BITMAP; GFLDLL;
function  gflAllockBitmap   ( TType              : GFL_BITMAP_TYPE;
                              width              : GFL_INT32;
                              height             : GFL_INT32;
                              bits_per_component : GFL_UINT16;
                              line_padding       : GFL_UINT32;
                              color              : PGFL_COLOR      ) : PGFL_BITMAP; GFLDLL;
procedure gflFreeBitmap     ( bmp                : PGFL_BITMAP     );               GFLDLL;
procedure gflFreeBitmapData ( bmp                : PGFL_BITMAP     );               GFLDLL;
function  gflCloneBitmap    ( bmp                : PGFL_BITMAP     ) : PGFL_BITMAP; GFLDLL;

{ METADATA }

function  gflBitmapHasEXIF             ( bmp       : PGFL_BITMAP    ) : GFL_BOOL;       GFLDLL;
function  gflBitmapHasIPTC             ( bmp       : PGFL_BITMAP    ) : GFL_BOOL;       GFLDLL;
procedure gflBitmapRemoveEXIFThumbnail ( bmp       : PGFL_BITMAP    );                  GFLDLL;
procedure gflBitmapRemoveMetaData      ( bmp       : PGFL_BITMAP    );                  GFLDLL;
function  gflBitmapGetIPTC             ( bmp       : PGFL_BITMAP    ) : PGFL_IPTC_DATA; GFLDLL;
procedure gflFreeIPTC                  ( iptc_data : PGFL_IPTC_DATA );                  GFLDLL;
function  gflBitmapGetEXIF             ( bmp       : PGFL_BITMAP;
                                         flags     : GFL_UINT32     ) : PGFL_EXIF_DATA; GFLDLL;
procedure gflFreeEXIF                  ( exif_data : PGFL_EXIF_DATA );                  GFLDLL;
procedure gflBitmapSetComment          ( bmp       : PGFL_BITMAP;
                                         comment   : PCHAR          );                  GFLDLL;

{ For DPX LUT }
function gflIsLutFile           ( filename             : PCHAR         ) : GFL_BOOL;  GFLDLL;
function gflIsCompatibleLutFile ( filename             : PCHAR;
                                  components_per_pixel : GFL_INT32;
                                  bits_per_component   : GFL_INT32;
                                  lut_type             : PGFL_LUT_TYPE ) : GFL_BOOL;  GFLDLL;
function gflApplyLutFile        ( bmp_src              : PGFL_BITMAP;
                                  bmp_dst              : PPGFL_BITMAP;
                                  filename             : PCHAR;
                                  lut_type             : PGFL_LUT_TYPE ) : GFL_ERROR; GFLDLL;


{ Bitmap modifiers }
const
   GFL_RESIZE_QUICK    = 0;
   GFL_RESIZE_BILINEAR = 1;

function  gflResize ( src     : PGFL_BITMAP;
                      dst     : PPGFL_BITMAP;
                      width   : GFL_INT32;
                      height  : GFL_INT32;
                      method  : GFL_INT32;
                      flags   : GFL_UINT32  ) : GFL_ERROR; GFLDLL;
{
 * ~~ DOESN'T WORKS YET WITH MORE THAN 8BITS PER COMPONENT!
}

type
   GFL_MODE = GFL_UINT16;

const
   GFL_MODE_TO_BINARY     =  1;
   GFL_MODE_TO_4GREY      =  2;
   GFL_MODE_TO_8GREY      =  3;
   GFL_MODE_TO_16GREY     =  4;
   GFL_MODE_TO_32GREY     =  5;
   GFL_MODE_TO_64GREY     =  6;
   GFL_MODE_TO_128GREY    =  7;
   GFL_MODE_TO_216GREY    =  8;
   GFL_MODE_TO_256GREY    =  9;
   GFL_MODE_TO_8COLORS    = 12;
   GFL_MODE_TO_16COLORS   = 13;
   GFL_MODE_TO_32COLORS   = 14;
   GFL_MODE_TO_64COLORS   = 15;
   GFL_MODE_TO_128COLORS  = 16;
   GFL_MODE_TO_216COLORS  = 17;
   GFL_MODE_TO_256COLORS  = 18;
   GFL_MODE_TO_RGB        = 19;
   GFL_MODE_TO_RGBA       = 20;
   GFL_MODE_TO_BGR        = 21;
   GFL_MODE_TO_ABGR       = 22;
   GFL_MODE_TO_BGRA       = 23;
   GFL_MODE_TO_ARGB       = 24;

   GFL_MODE_TO_TRUECOLORS = GFL_MODE_TO_RGB;

type
   GFL_MODE_PARAMS = GFL_UINT16;

const
   GFL_MODE_NO_DITHER        = 0;
   GFL_MODE_PATTERN_DITHER   = 1;
   GFL_MODE_HALTONE45_DITHER = 2;  // Only with GFL_MODE_TO_BINARY
   GFL_MODE_HALTONE90_DITHER = 3;  // Only with GFL_MODE_TO_BINARY
   GFL_MODE_ADAPTIVE         = 4;
   GFL_MODE_FLOYD_STEINBERG  = 5;  // Only with GFL_MODE_TO_BINARY

function  gflChangeColorDepth ( src     : PGFL_BITMAP;
                                dst     : PPGFL_BITMAP;
                                mode    : GFL_MODE;
                                params  : GFL_MODE_PARAMS ) : GFL_ERROR; GFLDLL;

{ This function was a macro }
function  gflGetBitmapPtr     ( _bitmap : PGFL_BITMAP;
                                _y      : GFL_INT32   ) : Pointer;

function  gflGetColorAt       ( src     : PGFL_BITMAP;
                                x       : GFL_INT32;
                                y       : GFL_INT32;
                                color   : PGFL_COLOR  ) : GFL_ERROR; GFLDLL;
function  gflSetColorAt       ( src     : PGFL_BITMAP;
                                x       : GFL_INT32;
                                y       : GFL_INT32;
                                color    : PGFL_COLOR  ) : GFL_ERROR; GFLDLL;

{ Manipulation of Bitmaps }
type
   GFL_RECT  = record
                 x, y, w, h : GFL_INT32;
               end;
   PGFL_RECT = ^GFL_RECT;

type
   GFL_POINT  = record
                  x, y : GFL_INT32;
                end;
   PGFL_POINT = ^GFL_POINT;

function  gflFlipVertical   ( src       : PGFL_BITMAP;
                              dst       : PPGFL_BITMAP ) : GFL_ERROR; GFLDLL;
function  gflFlipHorizontal ( src       : PGFL_BITMAP;
                              dst       : PPGFL_BITMAP ) : GFL_ERROR; GFLDLL;
function  gflCrop           ( src       : PGFL_BITMAP;
                              dst       : PPGFL_BITMAP;
                              rect      : PGFL_RECT    ) : GFL_ERROR; GFLDLL;
function  gflAutoCrop       ( src       : PGFL_BITMAP;
                              dst       : PPGFL_BITMAP;
                              color     : PGFL_COLOR;
                              tolerance : GFL_INT32    ) : GFL_ERROR; GFLDLL;
function  gflAutoCrop2      ( src       : PGFL_BITMAP;
                              dst       : PPGFL_BITMAP;
                              color     : PGFL_COLOR;
                              tolerance : GFL_INT32    ) : GFL_ERROR; GFLDLL;

{ Canvas reseizing }
type
  GFL_CANVASRESIZE = GFL_UINT32;

const
   GFL_CANVASRESIZE_TOPLEFT     = 0;
   GFL_CANVASRESIZE_TOP         = 1;
   GFL_CANVASRESIZE_TOPRIGHT    = 2;
   GFL_CANVASRESIZE_LEFT        = 3;
   GFL_CANVASRESIZE_CENTER      = 4;
   GFL_CANVASRESIZE_RIGHT       = 5;
   GFL_CANVASRESIZE_BOTTOMLEFT  = 6;
   GFL_CANVASRESIZE_BOTTOM      = 7;
   GFL_CANVASRESIZE_BOTTOMRIGHT = 8;

function  gflResizeCanvas  ( src              : PGFL_BITMAP;
                             dst              : PPGFL_BITMAP;
                             width            : GFL_INT32;
                             height           : GFL_INT32;
                             mode             : GFL_CANVASRESIZE;
                             color            : PGFL_COLOR       ) : GFL_ERROR; GFLDLL;

{ More Bitmap manipulation }
function  gflRotate        ( src              : PGFL_BITMAP;
                             dst              : PPGFL_BITMAP;
                             angle            : GFL_INT32;
                             background_color : PGFL_COLOR       ) : GFL_ERROR; GFLDLL;
function  gflRotateFine    ( src              : PGFL_BITMAP;
                             dst              : PPGFL_BITMAP;
                             angle            : DOUBLE;
                             background_color : PGFL_COLOR       ) : GFL_ERROR; GFLDLL;
function  gflReplaceColor  ( src              : PGFL_BITMAP;
                             dst              : PPGFL_BITMAP;
                             color            : PGFL_COLOR;
                             new_color        : PGFL_COLOR;
                             tolerance        : GFL_INT32         ) : GFL_ERROR; GFLDLL;

function  gflBitblt        ( src              : PGFL_BITMAP;
                             rect             : PGFL_RECT;
                             dst              : PGFL_BITMAP;
                             x_dest           : GFL_INT32;
                             y_dest           : GFL_INT32         ) : GFL_ERROR; GFLDLL;
function  gflMerge         ( src              : PGFL_BITMAP;      // Actually a pointer to an array of values
                             origin           : PGFL_POINT;       // Actually a pointer to an array of values
                             opacity          : PGFL_UINT32;      // Actually a pointer to an array of values
                             num_bitmap       : GFL_INT32;        // Number of values
                             dst              : PPGFL_BITMAP      ) : GFL_ERROR; GFLDLL;

{
  ------------------------------------------------------------------------------------------------------------------
  functions in LibGflExxx.dll
  ------------------------------------------------------------------------------------------------------------------
}

{ More Info }
function  gflGetNumberOfColorsUsed ( src         : PGFL_BITMAP ) : GFL_UINT32; GFLEDLL;

{ Bitmap color manipulations }
function  gflNegative              ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflBrightness            ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     brightness  : GFL_INT32    ) : GFL_ERROR; GFLEDLL;
function  gflContrast              ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     contrast    : GFL_INT32    ) : GFL_ERROR; GFLEDLL;
function  gflGamma                 ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     gamma       : DOUBLE       ) : GFL_ERROR; GFLEDLL;
function  gflLogCorrection         ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflNormalize             ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEqualize              ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEqualizeOnLuminance   ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflBalance               ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     color       : PGFL_COLOR  ) : GFL_ERROR; GFLEDLL;
function  gflAdjust                ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     brightness  : GFL_INT32;
                                     contrast    : GFL_INT32;
                                     gamma       : DOUBLE      ) : GFL_ERROR; GFLEDLL;
function  gflAdjustHLS             ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     hue         : GFL_INT32;
                                     lightness   : GFL_INT32;
                                     saturation  : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflSepia                 ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     percent     : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflSepiaEx               ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     percent     : GFL_INT32;
                                     color       : PGFL_COLOR  ) : GFL_ERROR; GFLEDLL;

{ Bitmap filter application }
function  gflAverage               ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     filter_size : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflSoften                ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     percentage  : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflBlur                  ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     percentage  : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflGaussianBlur          ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     filter_size : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflMaximum               ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     filter_size : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflMinimum               ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     filter_size : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflMedianBox             ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     filter_size : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflMedianCross           ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     filter_size : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflSharpen               ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP;
                                     percentage  : GFL_INT32   ) : GFL_ERROR; GFLEDLL;
function  gflEnhanceDetail         ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEnhanceFocus          ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflFocusRestoration      ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEdgeDetectLight       ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEdgeDetectMedium      ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEdgeDetectHeavy       ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEmboss                ( src         : PGFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
function  gflEmbossMore            ( src         : GFL_BITMAP;
                                     dst         : PPGFL_BITMAP ) : GFL_ERROR; GFLEDLL;
{ CONVOLVE }
type
   GFL_FILTER  = record
                   Size    : GFL_INT16;
                   Matrix  : array[0 .. 7*7 - 1] of GFL_INT16;
                   Divisor : GFL_INT16;
                   Bias    : GFL_INT16;
                 end;
   PGFL_FILTER = ^GFL_FILTER;

function  gflConvolve ( src     : PGFL_BITMAP;
                        dst     : PPGFL_BITMAP;
                        filter  : PGFL_FILTER  ) : GFL_ERROR; GFLEDLL;

{ Color Swapping }
type
   GFL_SWAPCOLORS_MODE = GFL_UINT16;

const
   GFL_SWAPCOLORS_RBG = 0;
   GFL_SWAPCOLORS_BGR = 1;
   GFL_SWAPCOLORS_BRG = 2;
   GFL_SWAPCOLORS_GRB = 3;
   GFL_SWAPCOLORS_GBR = 4;

function  gflSwapColors ( src     : PGFL_BITMAP;
                          dst     : PPGFL_BITMAP;
                          mode    : GFL_SWAPCOLORS_MODE ) : GFL_ERROR; GFLEDLL;

{ JPEG LOSSLESS }
type
  GFL_LOSSLESS_TRANSFORM = GFL_UINT16;

const
   GFL_LOSSLESS_TRANSFORM_NONE            = 0;
   GFL_LOSSLESS_TRANSFORM_ROTATE90        = 1;
   GFL_LOSSLESS_TRANSFORM_ROTATE180       = 2;
   GFL_LOSSLESS_TRANSFORM_ROTATE270       = 3;
   GFL_LOSSLESS_TRANSFORM_VERTICAL_FLIP   = 4;
   GFL_LOSSLESS_TRANSFORM_HORIZONTAL_FLIP = 5;

function  gflJpegLosslessTransform ( filename   : PChar;
                                     transform  : GFL_LOSSLESS_TRANSFORM  ) : GFL_ERROR; GFLEDLL;

{ Windows specific conversion }
function  gflConvertBitmapIntoDIB ( src         : PGFL_BITMAP;
                                    var hDIB    : HANDLE                ) : GFL_ERROR; GFLEDLL;
function  gflConvertBitmapIntoDDB ( src         : PGFL_BITMAP;
                                    var hBmp    : HBITMAP               ) : GFL_ERROR; GFLEDLL;
function  gflConvertDIBIntoBitmap ( hDIB        : HANDLE;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflConvertDDBIntoBitmap ( hBmp        : HBITMAP;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;

{ Windows specific loading }
function  gflLoadBitmapIntoDIB    ( filename    : PChar;
                                    var hDIB    : HANDLE;
                                    params      : PGFL_LOAD_PARAMS;
                                    info        : PGFL_FILE_INFORMATION ) : GFL_ERROR; GFLEDLL;
function  gflLoadBitmapIntoDDB    ( filename    : PChar;
                                    var hBmp    : HBITMAP;
                                    params      : PGFL_LOAD_PARAMS;
                                    info        : PGFL_FILE_INFORMATION ) : GFL_ERROR; GFLEDLL;

{ Windows specific adding text }
function  gflAddText              ( src         : PGFL_BITMAP;
                                    text1       : PChar;
                                    font_name   : PChar;
                                    x           : GFL_INT32;
                                    y           : GFL_INT32;
                                    font_size   : GFL_INT32;
                                    orientation : GFL_INT32;
                                    italic      : GFL_BOOL;
                                    bold        : GFL_BOOL;
                                    strike_out  : GFL_BOOL;
                                    underline   : GFL_BOOL;
                                    antialias   : GFL_BOOL;
                                    color       : PGFL_COLOR            ) : GFL_ERROR; GFLEDLL;

{ Windows specific clipboard functions }
function  gflImportFromClipboard  ( dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflExportIntoClipboard  ( src         : PGFL_BITMAP           ) : GFL_ERROR; GFLEDLL;
function  gflImportFromHWND       ( window      : HWND;
                                    rect        : PGFL_RECT;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;

{ Drawing functions }
type
   GFL_LINE_STYLE = GFL_UINT32;

const
   GFL_LINE_STYLE_SOLID      = 0;
   GFL_LINE_STYLE_DASH       = 1;
   GFL_LINE_STYLE_DOT        = 2;
   GFL_LINE_STYLE_DASHDOT    = 3;
   GFL_LINE_STYLE_DASHDOTDOT = 4;

function  gflDrawPointColor       ( src         : PGFL_BITMAP;
                                    x, y        : GFL_INT32;
                                    line_width  : GFL_UINT32;
                                    line_color  : PGFL_COLOR;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflDrawLineColor        ( src         : PGFL_BITMAP;
                                    x0          : GFL_INT32;
                                    y0          : GFL_INT32;
                                    x1          : GFL_INT32;
                                    y1          : GFL_INT32;
                                    line_width  : GFL_UINT32;
                                    line_color  : PGFL_COLOR;
                                    line_style  : GFL_LINE_STYLE;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflDrawPolylineColor    ( src         : PGFL_BITMAP;
                                    points      : PGFL_POINT;
                                    num_points  : GFL_INT32;
                                    line_width  : GFL_UINT32;
                                    line_color  : PGFL_COLOR;
                                    line_style  : GFL_LINE_STYLE;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflDrawPolygonColor     ( src         : PGFL_BITMAP;
                                    points      : PGFL_POINT;
                                    num_points  : GFL_INT32;
                                    fill_color  : PGFL_COLOR;
                                    line_width  : GFL_UINT32;
                                    line_color  : PGFL_COLOR;
                                    line_style  : GFL_LINE_STYLE;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflDrawRectangleColor   ( src         : PGFL_BITMAP;
                                    x0, y0      : GFL_INT32;
                                    width       : GFL_INT32;
                                    height      : GFL_INT32;
                                    line_width  : GFL_UINT32;
                                    line_color  : PGFL_COLOR;
                                    line_style  : GFL_LINE_STYLE;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;
function  gflDrawCircleColor      ( src         : PGFL_BITMAP;
                                    x           : GFL_INT32;
                                    y           : GFL_INT32;
                                    radius      : GFL_INT32;
                                    fill_Color  : PGFL_COLOR;
                                    line_width  : GFL_UINT32;
                                    line_color  : PGFL_COLOR;
                                    line_style  : GFL_LINE_STYLE;
                                    dst         : PPGFL_BITMAP          ) : GFL_ERROR; GFLEDLL;


implementation

{ This functions was a macro }
function gfl_IsTrueColors ( _a : GFL_BITMAP_TYPE ) : Boolean;
  { Check if type _a is a True Color image-type. }
  begin
    gfl_IsTrueColors := (_a and (GFL_RGB or GFL_BGR or GFL_RGBA or GFL_ABGR or GFL_BGRA or GFL_ARGB or GFL_CMYK)) <> 0
  end;

{ Renamed function, these were macro's }
procedure gflGetDefaultPreviewParams      ( params      : PGFL_LOAD_PARAMS      );
  begin
    gflGetDefaultThumbnailParams(params);
  end;

function  gflLoadPreview                  ( filename    : PChar;
                                            width       : GFL_INT32;
                                            height      : GFL_INT32;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;
  begin
    result := gflLoadThumbnail( filename, width, height, bmp, params, info );
  end;

function  gflLoadPreviewFromHandle        ( hGFL        : GFL_HANDLE;
                                            width       : GFL_INT32;
                                            height      : GFL_INT32;
                                            bmp         : PPGFL_BITMAP;
                                            params      : PGFL_LOAD_PARAMS;
                                            info        : PGFL_FILE_INFORMATION ) : GFL_ERROR;
  begin
    result := gflLoadThumbnailFromHandle( hGFL, width, height, bmp, params, info );
  end;

{ This function was a macro }
function gflGetBitmapPtr ( _bitmap : PGFL_BITMAP;
                           _y      : GFL_INT32   ) : Pointer;
  { Gets adress of bitmap data at line Y }
  begin
    Result := Pointer(Longint(_Bitmap^.Data) + _y * _bitmap^.BytesPerLine);
  end;

{$macro off}

initialization
  gflSetPluginsPathname(PlugIns);
  gflLibraryInit;
  gflEnableLZW( GFL_TRUE );

finalization
  gflLibraryExit;

end.

